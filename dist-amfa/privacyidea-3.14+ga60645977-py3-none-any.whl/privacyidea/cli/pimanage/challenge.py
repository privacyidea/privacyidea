# SPDX-FileCopyrightText: (C) 2024 Cornelius Kölbel <cornelius.koelbel@netknights.it>
#
# SPDX-License-Identifier: AGPL-3.0-or-later
#
# Info: https://privacyidea.org
#
# This code is free software: you can redistribute it and/or
# modify it under the terms of the GNU Affero General Public License
# as published by the Free Software Foundation, either
# version 3 of the License, or any later version.
#
# This code is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU Affero General Public License for more details.
#
# You should have received a copy of the GNU Affero General Public
# License along with this program. If not, see <http://www.gnu.org/licenses/>.

import datetime
import click
from flask.cli import AppGroup

from privacyidea.models import Challenge
from privacyidea.lib.challenge import _build_challenge_criterion, cleanup_expired_challenges

challenge_cli = AppGroup("challenge", help="Manage challenge data")


@challenge_cli.command("cleanup",
                       help="Clean up all expired challenges in the database. "
                            "Redis-cached challenges expire automatically via TTL "
                            "and are not affected by this command.")
@click.option('--chunksize', type=int,
              help="Delete entries in chunks of the given size to avoid deadlocks")
@click.option('--age', type=int,
              help="Instead of deleting expired challenges "
                   "delete challenge entries older than these number of minutes.")
@click.option('--dryrun', is_flag=True,
              help="Do not actually delete, only show what would be done.")
def cleanup_challenge(chunksize: int, age: int, dryrun: bool = False) -> int:
    """
    Delete all expired challenges from the challenge table.

    Note: when the Redis challenge cache is active, new challenges are stored
    in Redis only and have no DB rows. Redis manages their lifetime via TTL,
    so this command will report 0 deletions in a fully Redis-backed
    deployment — that is expected, not a sign of a leak.
    """
    if age is not None:
        # Delete challenges created earlier than age minutes ago, even if they are still valid
        now = datetime.datetime.utcnow() - datetime.timedelta(minutes=age)
        click.echo(f"Deleting challenges older than {now!s}")
    else:
        # Delete expired challenges
        click.echo("Deleting expired challenges.")

    criterion = _build_challenge_criterion(age)

    if dryrun:
        row_count = Challenge.query.filter(criterion).count()
        click.echo(f"Would delete {row_count!s} challenge entries.")
    else:
        row_count = cleanup_expired_challenges(chunk_size=chunksize, age=age)
        click.echo(f"{row_count!s} entries deleted.")
    return row_count
