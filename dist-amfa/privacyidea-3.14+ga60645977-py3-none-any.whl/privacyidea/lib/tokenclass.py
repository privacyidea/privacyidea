#  2022-02-03 Cornelius Kölbel <cornelius.koelbel@netknights.it>
#             Add verified enrollment
#  2018-01-21 Cornelius Kölbel <cornelius.koelbel@netknights.it>
#             Implement tokenkind. Token can be hardware, software or virtual
#  2017-07-08 Cornelius Kölbel <cornelius.koelbel@netknights.it>
#             Failcount unlock
#  2017-04-27 Cornelius Kölbel <cornelius.koelbel@netknights.it>
#             Change dateformat
#  2016-06-21 Cornelius Kölbel <cornelius.koelbel@netknights.it>
#             Add method to set the next_pin_change and next_password_change.
#  2016-04-29 Cornelius Kölbel <cornelius.koelbel@netknights.it>
#             Add get_default_settings to change the parameters before
#             the token is created
#  2016-04-08 Cornelius Kölbel <cornelius@privacyidea.org>
#             Avoid consecutive if statements
#             Remove unreachable code
#  2015-12-18 Cornelius Kölbel <cornelius@privacyidea.org>
#             Add get_setting_type
#  2015-10-12 Cornelius Kölbel <cornelius@privacyidea.org>
#             Add testconfig classmethod
#  2015-09-07 Cornelius Kölbel <cornelius@privacyidea.org>
#             Add challenge response decorator
#  2015-08-27 Cornelius Kölbel <cornelius@privacyidea.org>
#             Add revocation of token
#  * Nov 27, 2014 Cornelius Kölbel <cornelius@privacyidea.org>
#                 Migration to flask
#                 Rewrite of methods
#                 100% test code coverage
#  * Oct 03, 2014 Cornelius Kölbel <cornelius@privacyidea.org>
#                 Move the QR stuff in getInitDetail into the token classes
#  * Sep 17, 2014 Cornelius Kölbel, cornelius@privacyidea.org
#                 Improve the return value of the InitDetail
#  * May 08, 2014 Cornelius Kölbel
#
#  License:  AGPLv3
#  contact:  http://www.privacyidea.org
#
#  Copyright (C) 2010 - 2014 LSE Leading Security Experts GmbH
#  License:  AGPLv3
#  contact:  http://www.linotp.org
#            http://www.lsexperts.de
#            linotp@lsexperts.de
#
# This code is free software; you can redistribute it and/or
# modify it under the terms of the GNU AFFERO GENERAL PUBLIC LICENSE
# License as published by the Free Software Foundation; either
# version 3 of the License, or any later version.
#
# This code is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU AFFERO GENERAL PUBLIC LICENSE for more details.
#
# You should have received a copy of the GNU Affero General Public
# License along with this program.  If not, see <http://www.gnu.org/licenses/>.
#
"""
This is the Token Base class, which is inherited by all token types.
It depends on lib.user and lib.config.

The token object also contains a database token object as self.token.
The token object runs the self.update() method during the initialization
process in the API /token/init.

The update method takes a dictionary. Some of the following parameters:

otpkey      -> the token gets created with this OTPKey
genkey      -> genkey=1 : privacyIDEA generates an OTPKey, creates the token
               and sends it to the client.
2stepinit   -> Will do a two step rollout.
               privacyIDEA creates the first part of the OTPKey, sends it
               to the client and the clients needs to send back the second part.

In case of 2stepinit the key is generated from the server_component and the
client_component using the TokenClass method generate_symmetric_key.
This method is supposed to be overwritten by the corresponding token classes.
"""
import hashlib
import logging
import traceback
from base64 import b32encode
from binascii import unhexlify
from datetime import datetime, timedelta, timezone

from dateutil.parser import parse as parse_date_string, ParserError
from dateutil.tz import tzlocal, tzutc
from flask_babel import lazy_gettext
from sqlalchemy import select, delete

from privacyidea.lib import _
from privacyidea.lib.conditional_access.authentication_event_types import (AUTH_EVENT_REASON_KEY, AuthEventReason,
                                                                          CHALLENGE_LAPSED_KEY)
from privacyidea.lib.crypto import (decryptPassword,
                                    generate_otpkey, encryptPassword)
from privacyidea.lib.params import get_optional, get_required
from privacyidea.lib.tokenrolloutstate import RolloutState
from privacyidea.lib.utils import (is_true, decode_base32check,
                                   to_unicode, create_img, parse_timedelta,
                                   parse_legacy_time, split_pin_pass)
from .challenge import get_challenges
from .challenge_types import ChallengeSession
# Re-exported for backwards compatibility: these live in challenge_types so that
# models.challenge and lib.cache.redis can import them without a circular import.
from .challenge_types import (  # noqa: F401
    CHALLENGE_REFUSAL_STATUS,
    CHALLENGE_REFUSAL_SESSIONS,
    is_challenge_open,
)
from .config import (get_from_config, get_prepend_pin)
from .decorators import check_token_locked
from .error import (TokenAdminError,
                    ParameterError, PolicyError, ResourceNotFoundError)
from .log import log_with, redacted_attributes
from .policies.actions import PolicyAction
from .policydecorators import libpolicy, auth_otppin, challenge_response_allowed
from .resolver import get_resolver_type
from .user import (User)
from ..models import (TokenOwner, TokenTokengroup, cleanup_challenges, TokenInfo, db, TokenRealm, Realm,
                      Tokengroup, TokenCredentialIdHash)
from ..models.token import TOKENINFO_TYPE_SUFFIX

DATE_FORMAT = '%Y-%m-%dT%H:%M%z'
AUTH_DATE_FORMAT = "%Y-%m-%d %H:%M:%S.%f%z"
FAILCOUNTER_EXCEEDED = "failcounter_exceeded"
FAILCOUNTER_CLEAR_TIMEOUT = "failcounter_clear_timeout"

TWOSTEP_DEFAULT_CLIENTSIZE = 8
TWOSTEP_DEFAULT_DIFFICULTY = 10000

log = logging.getLogger(__name__)


class Tokenkind:
    SOFTWARE = "software"
    HARDWARE = "hardware"
    VIRTUAL = "virtual"


class AuthenticationMode:
    AUTHENTICATE = 'authenticate'
    CHALLENGE = 'challenge'
    # If the challenge is answered out of band
    OUTOFBAND = 'outofband'


class ClientMode:
    """
    This informs privacyIDEA clients how to handle challenge-responses
    """
    INTERACTIVE = 'interactive'
    POLL = 'poll'
    WEBAUTHN = 'webauthn'


class TokenClass:
    # Class properties
    using_pin = True
    hKeyRequired = False
    mode = [AuthenticationMode.AUTHENTICATE, AuthenticationMode.CHALLENGE]
    client_mode = ClientMode.INTERACTIVE
    # If the token provides means that the user has to prove/verify that the token was successfully enrolled.
    can_verify_enrollment = False

    desc_key_gen = lazy_gettext("Force the key to be generated on the server.")

    # Token info keys that this token class owns: they are written by the token class itself or by an endpoint
    # that has its own dedicated action, and their value decides how the token authenticates or whether it may
    # authenticate at all. They are not free-form metadata an administrator may edit, so a generic token info
    # write must not reach them.
    #
    # A class only declares the keys it introduces itself, the effective set is the union over the class
    # hierarchy. Use owned_tokeninfo_prefixes for a whole namespace such as "radius.". A class whose keys are
    # not known up front (the questions of a questionnaire token) overrides is_owned_tokeninfo_key instead.
    owned_tokeninfo_keys = frozenset({
        "assignment_date",
        "count_auth",
        "count_auth_max",
        "count_auth_success",
        "count_auth_success_max",
        "creation_date",
        FAILCOUNTER_EXCEEDED,
        "hashlib",
        "import_date",
        PolicyAction.LASTAUTH,
        "next_password_change",
        "next_pin_change",
        "tokenkind",
        "validity_period_end",
        "validity_period_start",
    })
    owned_tokeninfo_prefixes = frozenset()

    # Owned keys that may still be removed through a generic token info write, declared the same way. The value
    # of an owned key is issued by the server and is not written from a request, but removing the entry only
    # drops the capability it carries, which is a legitimate administrative action.
    deletable_tokeninfo_keys = frozenset()
    deletable_tokeninfo_prefixes = frozenset()

    # Owned keys that POST /token/set may write, declared the same way. An owned key is either issued by the
    # server, e.g. the sign count of a passkey, or supplied at enrollment, e.g. the server a radius token
    # forwards to. The second kind does change over the lifetime of a token, so it is listed here and can be
    # written through that endpoint, which has its own action and audits every field it writes. The keys that
    # carry the secret of a token, e.g. the TANs of a TAN token or the public id a yubikey is recognized by,
    # are deliberately not listed: those only change by enrolling or rolling over the token.
    settable_tokeninfo_keys = frozenset({
        "count_auth_max",
        "count_auth_success_max",
        "hashlib",
        "validity_period_end",
        "validity_period_start",
    })
    settable_tokeninfo_prefixes = frozenset()

    @classmethod
    def _collect_tokeninfo_declaration(cls, keys_attribute: str, prefixes_attribute: str) -> tuple:
        """
        Return the effective (keys, prefixes) of one token info declaration, as the union of everything declared
        along the class hierarchy. The result is cached per class, the declarations do not change at runtime.

        :param keys_attribute: Name of the class attribute holding the exact keys
        :param prefixes_attribute: Name of the class attribute holding the key prefixes
        :return: Tuple of a frozenset of keys and a frozenset of prefixes
        """
        cache_attribute = f"_collected_{keys_attribute}"
        collected = cls.__dict__.get(cache_attribute)
        if collected is None:
            keys = set()
            prefixes = set()
            for klass in cls.__mro__:
                keys.update(vars(klass).get(keys_attribute, ()))
                prefixes.update(vars(klass).get(prefixes_attribute, ()))
            collected = (frozenset(keys), frozenset(prefixes))
            setattr(cls, cache_attribute, collected)
        return collected

    @classmethod
    def is_owned_tokeninfo_key(cls, key: str) -> bool:
        """
        Whether the given token info key is owned by this token class, see owned_tokeninfo_keys.

        :param key: The token info key to check
        :return: True if the key is owned by the token class
        """
        keys, prefixes = cls._collect_tokeninfo_declaration("owned_tokeninfo_keys", "owned_tokeninfo_prefixes")
        return key in keys or any(key.startswith(prefix) for prefix in prefixes)

    def is_being_enrolled(self) -> bool:
        """
        Whether the token is still going through its enrollment, which includes a token that was just created,
        one waiting for the client and one waiting to be verified.

        init_token() updates an existing token when it is called with a serial that already exists, so update()
        runs both for an enrollment and for a request against a token that is already in use. The token info a
        token class writes from the enrollment parameters describes what the token authenticates against, so
        those entries belong to the enrollment and are only written while this returns True. They are changed
        later through POST /token/set.

        :return: True while the token is being enrolled
        """
        return self.token.rollout_state != RolloutState.ENROLLED

    @classmethod
    def is_deletable_tokeninfo_key(cls, key: str) -> bool:
        """
        Whether the given token info key may be removed through a generic token info write. Every key the token
        class does not own may be, and of the owned ones those declared in deletable_tokeninfo_keys.

        :param key: The token info key to check
        :return: True if the key may be deleted
        """
        if not cls.is_owned_tokeninfo_key(key):
            return True
        keys, prefixes = cls._collect_tokeninfo_declaration("deletable_tokeninfo_keys",
                                                            "deletable_tokeninfo_prefixes")
        return key in keys or any(key.startswith(prefix) for prefix in prefixes)

    @classmethod
    def is_settable_tokeninfo_key(cls, key: str) -> bool:
        """
        Whether POST /token/set may write the given token info key, see settable_tokeninfo_keys. A key the token
        class does not own is free-form and is written through the token info endpoints instead.

        :param key: The token info key to check
        :return: True if the key may be written through POST /token/set
        """
        if not cls.is_owned_tokeninfo_key(key):
            return False
        keys, prefixes = cls._collect_tokeninfo_declaration("settable_tokeninfo_keys",
                                                            "settable_tokeninfo_prefixes")
        return key in keys or any(key.startswith(prefix) for prefix in prefixes)

    @log_with(log)
    def __init__(self, db_token):
        """
        Create a new token object.

        :param db_token: A database token object
        :type db_token: Token
        :return: A TokenClass object
        """
        self.token = db_token
        self.type = db_token.tokentype
        # the init_details is a generic container, to store token specific
        # processing init_details e.g. for the initialization process
        # which could be retrieved in the controllers
        # this is not to be confused with the tokeninfo!
        self.init_details = {}
        # These are temporary details to store during authentication
        # like the "matched_otp_counter".
        self.auth_details = {}

    def set_type(self, tokentype):
        """
        Set the tokentype in this object and
        also in the underlying database-Token-object.

        :param tokentype: The type of the token like HOTP or TOTP
        :type tokentype: string
        """
        tokentype = '' + tokentype
        self.type = tokentype
        self.token.tokentype = tokentype

    @classmethod
    def is_outofband(cls):
        return AuthenticationMode.OUTOFBAND in cls.mode

    @staticmethod
    def get_class_type():
        return None

    @staticmethod
    def get_class_info(key=None, ret='all'):
        return {}

    @staticmethod
    def get_class_prefix():
        return "UNK"

    def get_type(self):
        return self.token.tokentype

    @check_token_locked
    def add_user(self, user, report=None, override=False):
        """
        Set the user attributes (uid, resolvername, resolvertype) of a token.

        :param user: a User() object, consisting of loginname and realm
        :param report: tbdf.
        :return: None
        """
        (uid, resolvertype, resolvername) = user.get_user_identifiers()
        # prevent to init update a token changing the token owner
        # FIXME: We need to remove this, if we one day want to assign several users to one token
        token_owner = self.user
        if not token_owner:
            new_owner = TokenOwner(token_id=self.token.id, user_id=uid, resolver=resolvername, realm_id=user.realm_id,
                                   realmname=user.realm)
            db.session.add(new_owner)
            # Add users realm to token realms
            self.set_realms([user.realm], add=True, commit_db_session=False)
            self.write_tokeninfo("assignment_date", datetime.now(timezone.utc).isoformat(timespec="seconds"),
                               commit_db_session=False)
            db.session.commit()
        elif token_owner != user:
            if override:
                # We remove the old user
                self.remove_user()
            else:
                log.warning(f"The token with serial {self.token.serial!s} is already assigned "
                            f"to user {self.user!s}. Can not assign to {user!s}.")
                raise TokenAdminError("This token is already assigned to another user.")

    def add_tokengroup(self, tokengroup: str = None, tokengroup_id: int = None):
        """
        Adds a new tokengroup to this token.

        :param tokengroup: The name of the token group to add
        :param tokengroup_id: The id of the tokengroup to add
        :return: True
        """
        if not tokengroup and not tokengroup_id:
            raise ParameterError("You either need to specify a tokengroup name or id.")

        statement = select(Tokengroup)
        if tokengroup:
            statement = statement.filter_by(name=tokengroup)
        if tokengroup_id:
            statement = statement.filter_by(id=tokengroup_id)
        tokengroup_db = db.session.execute(statement).scalar_one_or_none()
        if not tokengroup_db:
            log.error("Tokengroup %s does not exist. Cannot add it to token %s.", tokengroup, self.get_serial())
            raise ResourceNotFoundError(_("The tokengroup does not exist."))

        if tokengroup_db not in self.token.tokengroup_list:
            association = TokenTokengroup(token_id=self.token.id, tokengroup_id=tokengroup_db.id)
            db.session.add(association)
        else:
            log.debug("Token %s is already assigned to tokengroup %s.", self.get_serial(), tokengroup_db.name)

        return True

    @property
    def owner_realms(self) -> set[str]:
        """
        return all the realms of the token owners
        """
        realms = set()
        for tokenowner in self.token.all_owners:
            if tokenowner.realm:
                realms.add(tokenowner.realm.name)
        return realms

    @property
    def owners(self):
        """
        return all the owners of a token
        If the token has no owner assigned, we return an empty list

        :return: The owners of the token
        :rtype: A list of user object
        """
        user_objects = []
        for tokenowner in self.token.all_owners:
            realm_name = tokenowner.realm.name if tokenowner.realm else None
            user_object = User(resolver=tokenowner.resolver,
                               realm=realm_name,
                               uid=tokenowner.user_id)
            user_objects.append(user_object)
        return user_objects

    @property
    def user(self):
        """
        return the user (owner) of a token
        If the token has no owner assigned, we return None

        :return: The owner of the token
        :rtype: User object or None
        """
        user_object = None
        tokenowner = self.token.first_owner
        if tokenowner:
            realm_name = tokenowner.realm.name if tokenowner.realm else None
            user_object = User(resolver=tokenowner.resolver,
                               realm=realm_name,
                               uid=tokenowner.user_id)
        return user_object

    def remove_user(self):
        """
        Remove the user (owner) of a token.
        If the token has no owner assigned, we return None

        :return: The owner of the token
        :rtype: User object or None
        """
        user_object = self.user
        if user_object:
            self.token.first_owner.delete()
            self.token.save()
        return user_object

    def is_orphaned(self, orphaned_on_error=True):
        """
        Return True if the token is orphaned.

        An orphaned token means, that it has a user assigned, but the user
        does not exist in the user store (anymore)

        :return: True / False
        :rtype: bool
        """
        orphaned = False
        owner = self.token.first_owner
        if owner:
            if owner.resolver and not get_resolver_type(owner.resolver):
                # The resolver of the owner was deleted, so the user can not exist any more. This is certain, unlike
                # an error of the user store, which orphaned_on_error decides about.
                return True
            try:
                if not self.user or not self.user.login or not self.user.realm:
                    # The token is assigned, but the username does not resolve
                    orphaned = True
            except Exception:
                # If any other resolving error occurs, we also assume the
                # token to be orphaned per default, You can change this with
                # the parameter orphaned_on_error.
                orphaned = orphaned_on_error
        return orphaned

    def get_user_displayname(self):
        """
        Returns a tuple of a user identifier like user@realm and the
        displayname of "givenname surname".

        :return: tuple
        """
        user = self.user
        user_info = user.get_specific_info(["givenname", "surname"])
        user_identifier = f"{user.login!s}_{user.realm!s}"
        user_displayname = "{!s} {!s}".format(user_info.get("givenname", "."),
                                              user_info.get("surname", "."))
        return user_identifier, user_displayname

    @check_token_locked
    def reset(self):
        """
        Reset the failcounter
        """
        if self.token.failcount:
            # reset the failcounter and write to database
            self.set_failcount(0)
            self.token.save()

    @check_token_locked
    def add_init_details(self, key, value):
        """
        (was addInfo)
        Adds information to a volatile internal dict
        """
        self.init_details[key] = value
        return self.init_details

    @check_token_locked
    def set_init_details(self, details):
        if type(details) not in [dict]:
            raise Exception("Details setting: wrong data type - must be dict")
        self.init_details = details
        return self.init_details

    @log_with(log)
    def get_init_details(self):
        """
        return the status of the token rollout

        :return: return the status dict.
        :rtype: dict
        """
        return self.init_details

    @check_token_locked
    def set_tokeninfo(self, info: dict):
        """
        Set the tokeninfo field in the DB. Old values will be deleted. This replaces the whole token info of the
        token, including the keys the token class owns, so it is server side only.

        :param info: dictionary with key and value
        :return:
        """
        self.remove_tokeninfo()
        self.add_tokeninfo_dict(info)

    @check_token_locked
    def add_tokeninfo(self, key: str, value: str, value_type: str = None, commit_db_session: bool = True):
        """
        Add a key and a value to the DB tokeninfo on behalf of a request, e.g. the token info endpoints or the
        token event handler. A key the token class owns is refused, see owned_tokeninfo_keys: its value decides
        how the token authenticates, so it is maintained by the server and is not free-form metadata.

        Server side code that maintains such a key writes it with write_tokeninfo() instead.

        :param key:
        :param value:
        :param value_type: See write_tokeninfo()
        :param commit_db_session: See write_tokeninfo()
        :raises PolicyError: If the key is owned by the token class.
        :raises ParameterError: If the key uses the reserved ".type" suffix.
        """
        if self.is_owned_tokeninfo_key(key):
            log.info(f"Refusing to set the token info '{key}' of token {self.token.serial} through a generic "
                     f"token info write, the key is managed by the token.")
            raise PolicyError(f"The token info key '{key}' is managed by the token and can not be modified.")
        self.write_tokeninfo(key, value, value_type=value_type, commit_db_session=commit_db_session)

    @check_token_locked
    def write_tokeninfo(self, key: str, value: str, value_type: str = None, commit_db_session: bool = True) -> None:
        """
        Add a key and a value to the DB tokeninfo without checking whether the token class owns the key. This is
        the writer for server side code that maintains the token info of a token, a write that comes from a
        request has to go through add_tokeninfo() so that the owned keys stay under the control of the server.

        :param key:
        :param value:
        :param value_type: If type is "password", the value will be encrypted. If it is None and an entry for this
            key already exists, the type of that entry is kept. Callers that do not know about the type of a key
            must not silently turn an encrypted entry into a plaintext one, so clearing the type requires deleting
            the entry and adding it again.
        :param commit_db_session: Whether the database changes should be committed to be persistent. Only use false if
            you are doing multiple database changes with a final single commit.
        :raises ParameterError: If the key uses the reserved ".type" suffix.
        """
        # A "<key>.type" entry is not stored as a row, it is synthesized from the Type column of "<key>" when the
        # token info is read. A real row with that name would shadow the synthetic one and make the value of
        # "<key>" be read with the wrong type, so the suffix is reserved.
        if key.endswith(TOKENINFO_TYPE_SUFFIX):
            raise ParameterError(f"The token info key '{key}' uses the reserved "
                                 f"'{TOKENINFO_TYPE_SUFFIX}' suffix.")

        statement = select(TokenInfo).where(TokenInfo.token_id == self.token.id, TokenInfo.Key == key)
        token_info = db.session.execute(statement).scalar_one_or_none()

        if token_info is not None and value_type is None:
            value_type = token_info.Type

        if value_type == "password":
            value = encryptPassword(value)

        if token_info is None:
            # Create new info entry
            token_info = TokenInfo(token_id=self.token.id, Key=key, Value=value, Type=value_type)
            db.session.add(token_info)
        else:
            # Update existing info
            token_info.Value = value
            token_info.Type = value_type
        if commit_db_session:
            db.session.commit()

    @check_token_locked
    def add_tokeninfo_dict(self, info: dict):
        """
        Write several token info entries at once. Used server side, e.g. during enrollment and token import, so
        it writes the keys the token class owns as well.

        :param info: dictionary with key and value, optionally with "<key>.type" entries carrying the value type
        """
        for key, value in info.items():
            if key.endswith(TOKENINFO_TYPE_SUFFIX):
                continue
            value_type = info.get(f"{key}{TOKENINFO_TYPE_SUFFIX}", None)
            self.write_tokeninfo(key, value, value_type, commit_db_session=False)
        db.session.commit()

    @check_token_locked
    def check_otp(self, otpval, counter=None, window=None, options=None):
        """
        This checks the OTP value, AFTER the upper level did
        the checkPIN

        In the base class we do not know, how to calculate the
        OTP value. So we return -1.
        In case of success, we should return >=0, the counter

        :param otpval: the OTP value
        :param counter: The counter for counter based otp values
        :type counter: int
        :param window: a counter window
        :type counter: int
        :param options: additional token specific options
        :type options: dict
        :return: counter of the matching OTP value.
        :rtype: int
        """
        if not counter:
            counter = self.token.count
        if not window:
            window = self.token.count_window

        return -1

    def get_otp(self, current_time=""):
        """
        The default token does not support getting the otp value
        will return a tuple of four values
        a negative value is a failure.

        :return: something like:  (1, pin, otpval, combined)
        """
        return -2, 0, 0, 0

    def get_multi_otp(self, count=0, epoch_start=0, epoch_end=0,
                      curTime=None, timestamp=None):
        """
        This returns a dictionary of multiple future OTP values of a token.

        :param count: how many otp values should be returned
        :param epoch_start: time based tokens: start when
        :param epoch_end: time based tokens: stop when
        :param curTime: current time for TOTP token (for selftest)
        :type curTime: datetime object
        :param timestamp: unix time, current time for TOTP token (for selftest)
        :type timestamp: int

        :return: True/False, error text, OTP dictionary
        :rtype: Tuple
        """
        return False, "get_multi_otp not implemented for this tokentype", {}

    @libpolicy(auth_otppin)
    @check_token_locked
    def check_pin(self, pin, user=None, options=None):
        """
        Check the PIN of the given Password.
        Usually this is only dependent on the token itself,
        but the user object can cause certain policies.

        Each token could implement its own PIN checking behaviour.

        :param pin: the PIN (static password component), that is to be checked.
        :type pin: string
        :param user: for certain PIN policies (e.g. checking against the
                     user store) this is the user, whose
                     password would be checked. But at the moment we are
                     checking against the userstore in the decorator
                     "auth_otppin".
        :type user: User object
        :param options: the optional request parameters
        :return: If the PIN is correct, return True
        :rtype: bool
        """
        # Check PIN against the token database
        res = self.token.check_pin(pin)
        return res

    @check_token_locked
    def authenticate(self, passw, user=None, options=None):
        """
        High level interface which covers the check_pin and check_otp
        This is the method that verifies single shot authentication like
        they are done with push button tokens.

        It is a high level interface to support other tokens as well, which
        do not have a pin and otp separation - they could overwrite
        this method

        If the authentication succeeds an OTP counter needs to be increased,
        i.e. the OTP value that was used for this authentication is invalidated!

        :param passw: the password which could be pin+otp value
        :type passw: string
        :param user: The authenticating user
        :type user: User object
        :param options: dictionary of additional request parameters
        :type options: dict

        :return: returns tuple of

            1. true or false for the pin match,
            2. the otpcounter (int) and the
            3. reply (dict) that will be added as additional information in
                the JSON response of ``/validate/check``.

        :rtype: tuple(bool, int, dict)
        """
        pin_match = False
        otp_counter = -1
        reply = None

        (res, pin, otpval) = self.split_pin_pass(passw, user=user, options=options)
        if res:
            # If the otpvalue is too short, we do not check the PIN at all, since res is False
            pin_match = self.check_pin(pin, user=user, options=options)
            if pin_match is True:
                otp_counter = self.check_otp(otpval, options=options)

        return pin_match, otp_counter, reply

    @staticmethod
    def decode_otpkey(otpkey, otpkeyformat):
        """
        Decode the otp key which is given in a specific format.

        Supported formats:
         * ``hex``, in which the otpkey is returned verbatim
         * ``base32check``, which is specified in ``decode_base32check``

        In case the OTP key is malformed or if the format is unknown,
        a ParameterError is raised.

        :param otpkey: OTP key passed by the user
        :param otpkeyformat: "hex" or "base32check"
        :return: hex-encoded otpkey
        """
        if otpkeyformat == "hex":
            return otpkey
        elif otpkeyformat == "base32check":
            return decode_base32check(otpkey)
        else:
            raise ParameterError(f"Unknown OTP key format: {otpkeyformat!r}")

    def update(self, param, reset_failcount=True):
        """
        Update the token object

        :param param: a dictionary with different params like keysize,
                      description, genkey, otpkey, pin
        :type: param: dict
        """
        tdesc = get_optional(param, "description")
        rollover = get_optional(param, "rollover")
        if tdesc is not None:
            self.token.set_description(tdesc)

        # key_size as parameter overrules a prevoiusly set
        # value e.g. in hashlib in the upper classes
        key_size = int(get_optional(param, "keysize") or 20)

        #
        # process the otpkey:
        #   if otpkey given - take this
        #   if not given
        #       if genkey == 1 : create one
        #   if required and otpkey == None:
        #      raise param Exception, that we require an otpkey
        #
        otpKey = get_optional(param, "otpkey")
        genkey = is_true(get_optional(param, "genkey"))
        twostep_init = is_true(get_optional(param, "2stepinit"))
        verify = get_optional(param, "verify")
        otpkeyformat = get_optional(param, "otpkeyformat")

        if otpKey is not None and otpkeyformat is not None:
            # have to decode OTP key
            otpKey = self.decode_otpkey(otpKey, otpkeyformat)

        if twostep_init:
            if is_true(rollover):
                # We reset the rollout state
                self.token.rollout_state = None
            if self.token.rollout_state == RolloutState.CLIENTWAIT:
                # We do not do 2stepinit in the second step
                raise ParameterError("2stepinit is only to be used in the "
                                     "first initialization step.")
            # In a 2-step enrollment, the server always generates a key
            genkey = 1
            # The token is disabled
            self.token.active = False

        # if genkey not in [0, 1]:
        #    raise ParameterError("TokenClass supports only genkey in  range ["
        #                         "0,1] : %r" % genkey)

        if genkey and otpKey is not None:
            raise ParameterError('[ParameterError] You may either specify '
                                 'genkey or otpkey, but not both!', id=344)

        if otpKey is None and genkey and not verify:
            otpKey = self._genOtpKey_(key_size)

        # otpKey still None?? - raise the exception, if an otpkey is required, and we are not in verify state
        if otpKey is None and self.hKeyRequired is True and not verify:
            otpKey = get_required(param, "otpkey")

        if otpKey is not None:
            if self.token.rollout_state == RolloutState.CLIENTWAIT:
                # If we have otpkey and the token is in the enrollment-state
                # generate the new key
                server_component = to_unicode(self.token.get_otpkey().getKey())
                client_component = otpKey
                otpKey = self.generate_symmetric_key(server_component,
                                                     client_component,
                                                     param)
                self.token.rollout_state = ""
                self.token.active = True
            self.add_init_details('otpkey', otpKey)
            self.token.set_otpkey(otpKey, reset_failcount=reset_failcount)

        if twostep_init:
            # After the key is generated, we set "waiting for the client".
            self.token.rollout_state = RolloutState.CLIENTWAIT

        pin = get_optional(param, "pin")
        if pin is not None:
            store_hashed = True
            encrypt_pin = get_optional(param, "encryptpin")
            if is_true(encrypt_pin):
                store_hashed = False
            self.token.set_pin(pin, store_hashed)

        otplen = get_optional(param, 'otplen')
        if otplen is not None:
            self.set_otplen(otplen)

        # Add parameters starting with the tokentype-name to the tokeninfo. These are keys the token class owns,
        # e.g. the server a radius token forwards to, so they are only accepted while the token is being
        # enrolled, see is_being_enrolled().
        if self.is_being_enrolled():
            for p in param.keys():
                if p.startswith(self.type + "."):
                    self.write_tokeninfo(p, get_optional(param, p))
        else:
            ignored = [p for p in param.keys() if p.startswith(self.type + ".")]
            if ignored:
                log.info(f"Ignoring the parameters {ignored!s} for the already enrolled token "
                         f"{self.token.serial}, they are only set during the enrollment.")

        # The base class will be a software tokenkind
        self.write_tokeninfo("tokenkind", Tokenkind.SOFTWARE)

        return

    def _genOtpKey_(self, otpkeylen=None):
        """
        private method, to create an otpkey
        """
        if otpkeylen is None:
            if hasattr(self, 'otpkeylen'):
                otpkeylen = getattr(self, 'otpkeylen')
            else:
                otpkeylen = 20
        return generate_otpkey(otpkeylen)

    @check_token_locked
    def set_description(self, description):
        """
        Set the description on the database level

        :param description: description of the token
        :type description: string
        """
        self.token.set_description('' + description)
        return

    @check_token_locked
    def set_defaults(self):
        """
        Set the default values on the database level
        """
        self.token.otplen = int(get_from_config("DefaultOtpLen") or 6)
        self.token.count_window = int(get_from_config("DefaultCountWindow")
                                      or 10)
        self.token.maxfail = int(get_from_config("DefaultMaxFailCount") or 10)
        self.token.sync_window = int(get_from_config("DefaultSyncWindow")
                                     or 1000)

        self.token.tokentype = '' + self.type
        return

    @log_with(log)
    def delete_token(self):
        """
        delete the database token
        """
        # First delete all relationships that are not automatically removed by cascade delete
        delete_stmt_token_realm = delete(TokenRealm).where(TokenRealm.token_id == self.token.id)
        db.session.execute(delete_stmt_token_realm)

        # Routed through delete_challenges() so Redis-cached challenges
        # for this serial are invalidated alongside any DB rows; otherwise
        # transaction IDs would keep resolving until their TTL expires.
        # commit=False keeps the SQL DELETE inside this method's outer
        # transaction so token + challenge removal stays atomic on the DB
        # side (Redis eviction has no transaction concept and runs up-front).
        #
        # Caveat: if the outer transaction aborts after this point, the SQL
        # challenge rows are restored but the Redis entries are already gone.
        # Two cases:
        # * DB-only challenges (cache off, or fallback writes): the SQL row
        #   comes back on rollback, the next read finds it via the normal
        #   cache-miss -> DB-fallback path. No observable loss.
        # * Redis-only challenges (cache on, the steady state): there is no
        #   SQL twin to restore. In-flight authentications for those
        #   transaction IDs immediately fail with "challenge not found" and
        #   the user has to start the MFA flow over.
        # Token deletes rarely roll back in practice, but the asymmetry is
        # real - do not rely on cross-store transactional semantics.
        from privacyidea.lib.challenge import delete_challenges
        delete_challenges(serial=self.token.serial, commit=False)

        if self.get_tokentype().lower() in ["webauthn", "passkey"]:
            delete_stmt_token_credential = delete(TokenCredentialIdHash).where(
                TokenCredentialIdHash.token_id == self.token.id)
            db.session.execute(delete_stmt_token_credential)

        db.session.delete(self.token)
        db.session.commit()

    def save(self):
        """
        Save the database token
        """
        self.token.save()

    def resync(self, otp1, otp2, options=None):
        pass

    def get_otp_count_window(self):
        return self.token.count_window

    def get_otp_count(self):
        return self.token.count

    def is_active(self):
        return self.token.active

    def use_for_authentication(self, options):
        """
        This method checks, if this token should be used for authentication.
        Certain token classes could be excluded from the authentication request in
        certain situations.

        Returns True, if the token should be used for authentication.
        Returns False, if the token should be completely ignored for authentication.

        :param options: This is the option list, that basically contains the Request parameters.
        :return:
        """
        return True

    @property
    def rollout_state(self):
        return self.token.rollout_state

    def is_fit_for_challenge(self, messages, options=None):
        """
        This method is called if a cryptographically matching response to a challenge was found.
        This method may implement final checks, if there is anything that should deny the
        success of the authentication with the response to the challenge.

        The options dictionary can also contain the transaction_id, so even the
        challenge table for this token can be used for checking.

        :param options:
        :type options: dict
        :param messages: This is a list of messages. This method can append new information to this message list.
        :type messages: list
        :return: True or False
        """
        return self.check_all(messages)

    def get_failcount(self):
        return self.token.failcount

    @check_token_locked
    def set_failcount(self, failcount):
        """
        Set the failcounter in the database
        """
        self.token.failcount = failcount
        if failcount == 0:
            self.remove_tokeninfo(FAILCOUNTER_EXCEEDED)

    def get_max_failcount(self):
        return self.token.maxfail

    def get_user_id(self):
        tokenowner = self.token.first_owner
        return "" if not tokenowner else tokenowner.user_id

    def set_tokengroups(self, tokengroups: list[str], add: bool = False):
        """
        Set the list of the tokengroups of a token.

        :param tokengroups: token groups the token should be assigned to
        :param add: if the tokengroups should be added and not replaced
        """
        existing_groups: list[Tokengroup] = self.token.tokengroup_list
        new_groups: set[str] = set(tokengroups) - {group.name for group in existing_groups}
        if not add:
            # delete existing token groups which are not in the new list
            group_ids_to_delete = [group.id for group in existing_groups if group.name not in tokengroups]
            statement = delete(TokenTokengroup).where(TokenTokengroup.token_id == self.token.id,
                                                      TokenTokengroup.tokengroup_id.in_(group_ids_to_delete))
            db.session.execute(statement)

        # Add new token groups
        for group in new_groups:
            statement = select(Tokengroup).filter_by(name=group)
            tokengroup_db = db.session.execute(statement).scalar_one_or_none()
            if not tokengroup_db:
                log.warning("Tokengroup %s does not exist. Cannot add it to token %s.", group, self.get_serial())
                continue

            association = TokenTokengroup(token_id=self.token.id, tokengroup_id=tokengroup_db.id)
            db.session.add(association)

        db.session.commit()

    @check_token_locked
    def set_realms(self, realms: list[str], add: bool = False, commit_db_session: bool = True):
        """
        Set the list of the realms of a token.

        :param realms: realms the token should be assigned to
        :param add: if the realms should be added and not replaced
        :param commit_db_session: Whether the database changes should be committed to be persistent. Only use false if
            you are doing multiple database changes with a final single commit.
        """
        # get existing realms
        statement = select(TokenRealm).where(TokenRealm.token_id == self.token.id)
        existing_realms = db.session.scalars(statement).unique().all()
        existing_realm_names = {tr.realm.name for tr in existing_realms}
        realms_to_add = set(realms) - existing_realm_names

        if not add:
            # delete realms that are not in the new list
            realm_names_to_delete = existing_realm_names - set(realms)
            # exclude the realm of the owner from deletion
            if self.owner_realms:
                owner_realms_delete = realm_names_to_delete & self.owner_realms
                realm_names_to_delete = realm_names_to_delete - self.owner_realms
                if owner_realms_delete:
                    log.info(f"The realms ({', '.join(owner_realms_delete)}) of assigned users cannot be removed from "
                             f"the token {self.get_serial()}.")
            realms_to_delete = [realm for realm in existing_realms if realm.realm.name in realm_names_to_delete]
            if realms_to_delete:
                realm_ids = [realm.realm_id for realm in realms_to_delete]
                delete_stmt = delete(TokenRealm).where(TokenRealm.token_id == self.token.id)
                if len(realm_ids) > 0:
                    delete_stmt = delete_stmt.where(TokenRealm.realm_id.in_(realm_ids))
                db.session.execute(delete_stmt)
                log.debug(f"Remove realm {', '.join(realm_names_to_delete)} from token {self.get_serial()} due to "
                          f"setting new realms ({', '.join(realms)}).")

        for realm_name in realms_to_add:
            statement = select(Realm).filter_by(name=realm_name)
            realm_db = db.session.execute(statement).scalar_one_or_none()
            if realm_db:
                token_realm = TokenRealm(token_id=self.token.id, realm_id=realm_db.id)
                db.session.add(token_realm)
            else:  # pragma no cover
                # should already be covered on lib layer
                log.warning(f"Realm {realm_name} does not exist. Cannot add it to token {self.get_serial()}.")

        if commit_db_session:
            db.session.commit()

    def get_realms(self):
        """
        Return a list of realms the token is assigned to

        :return: realms
        :rtype: list
        """
        return self.token.get_realms()

    def get_serial(self):
        return self.token.serial

    def get_tokentype(self):
        return self.token.tokentype

    @check_token_locked
    def set_so_pin(self, soPin):
        self.token.set_so_pin(soPin)

    @check_token_locked
    def set_user_pin(self, userPin):
        self.token.set_user_pin(userPin)

    @check_token_locked
    def set_otpkey(self, otpKey):
        self.token.set_otpkey(otpKey)

    @check_token_locked
    def set_otplen(self, otplen):
        self.token.otplen = int(otplen)

    def get_otplen(self):
        return self.token.otplen

    @check_token_locked
    def set_otp_count(self, otpCount):
        self.token.count = int(otpCount)
        self.token.save()

    @check_token_locked
    def set_pin(self, pin, encrypt=False):
        """
        set the PIN of a token.
        Usually the pin is stored in a hashed way.

        :param pin: the pin to be set for the token
        :type pin: basestring
        :param encrypt: If set to True, the pin is stored encrypted and
            can be retrieved from the database again
        :type encrypt: bool
        """
        storeHashed = not encrypt
        self.token.set_pin(pin, storeHashed)

    def get_pin_hash_seed(self):
        return self.token.pin_hash, self.token.pin_seed

    @check_token_locked
    def set_pin_hash_seed(self, pinhash, seed):
        self.token.pin_hash = pinhash
        self.token.pin_seed = seed

    @check_token_locked
    def enable(self, enable=True):
        self.token.active = enable

    def revoke(self):
        """
        This revokes the token.
        By default, it
        1. sets the revoked-field
        2. set the locked field
        3. disables the token.

        Some token types may revoke a token without locking it.
        """
        self.token.revoked = True
        self.token.locked = True
        self.token.active = False

    def is_revoked(self):
        """
        Check if the token is in the revoked state

        :return: True, if the token is revoked
        """
        return self.token.revoked

    def is_locked(self):
        """
        Check if the token is in a locked state
        A locked token can not be modified

        :return: True, if the token is locked.
        """
        return self.token.locked

    @check_token_locked
    def set_maxfail(self, maxFail):
        self.token.maxfail = maxFail

    @check_token_locked
    def set_hashlib(self, hashlib):
        self.write_tokeninfo("hashlib", hashlib)

    @check_token_locked
    def inc_failcount(self):
        if self.token.failcount < self.token.maxfail:
            self.token.failcount = (self.token.failcount + 1)
            if self.token.failcount == self.token.maxfail:
                self.write_tokeninfo(FAILCOUNTER_EXCEEDED,
                                   datetime.now(tzlocal()).strftime(
                                       DATE_FORMAT))
        try:
            self.token.save()
        except Exception:  # pragma: no cover
            log.error('update failed')
            raise TokenAdminError("Token Fail Counter update failed", id=1106)
        return self.token.failcount

    @check_token_locked
    def set_count_window(self, countWindow):
        self.token.count_window = int(countWindow)

    def get_count_window(self):
        return self.token.count_window

    @check_token_locked
    def set_sync_window(self, syncWindow):
        self.token.sync_window = int(syncWindow)

    def get_sync_window(self):
        return self.token.sync_window

    # hashlib algorithms:
    # http://www.doughellmann.com/PyMOTW/hashlib/index.html#module-hashlib

    @staticmethod
    def get_hashlib(hLibStr):
        """
        Returns a hashlib function for a given string

        :param hLibStr: the hashlib
        :type hLibStr: string
        :return: the hashlib
        :rtype: function
        """
        if hLibStr is None:
            return hashlib.sha1

        hashlibStr = hLibStr.lower()

        if hashlibStr == "md5":
            return hashlib.md5
        elif hashlibStr == "sha1":
            return hashlib.sha1
        elif hashlibStr == "sha224":
            return hashlib.sha224
        elif hashlibStr == "sha256":
            return hashlib.sha256
        elif hashlibStr == "sha384":
            return hashlib.sha384
        elif hashlibStr == "sha512":
            return hashlib.sha512
        else:
            return hashlib.sha1

    def get_tokeninfo(self, key=None, default=None, decrypted=False):
        """
        return the complete token info or a single key of the tokeninfo.
        When returning the complete token info dictionary encrypted entries
        are not decrypted.
        If you want to receive a decrypted value, you need to call it
        directly with the key.

        :param key: the key to return
        :type key: string
        :param default: the default value, if the key does not exist
        :type default: string
        :param decrypted: Indicates that passwords should be decrypted when fetching the whole dict
        :type decrypted: bool
        :return: the value for the key
        :rtype: int or str or dict
        """
        tokeninfo = self.token.get_info()
        ret = tokeninfo

        if key:
            ret = tokeninfo.get(key, default)
            key_type = tokeninfo.get(key + TOKENINFO_TYPE_SUFFIX)
            if key_type == "password":
                ret = decryptPassword(ret)
        elif decrypted:
            ret = {x: (decryptPassword(y) if tokeninfo.get(x + TOKENINFO_TYPE_SUFFIX) == "password" else y)
                   for x, y in tokeninfo.items()}

        return ret

    def delete_tokeninfo(self, key: str = None):
        """
        Deletes the token info for the given key on behalf of a request, e.g. the token info endpoints or the
        token event handler. A key the token class owns is refused unless it is declared deletable, and so is
        deleting the whole token info, because that would remove the owned keys along with the free-form ones.

        Server side code that maintains such a key removes it with remove_tokeninfo() instead.

        :param key: The key to delete
        :raises PolicyError: If the key may not be deleted, or if no key is given.
        """
        if key is None:
            raise PolicyError("Deleting the whole token info of a token is not supported, the token would lose "
                              "the entries it needs to function.")
        if not self.is_deletable_tokeninfo_key(key):
            log.info(f"Refusing to delete the token info '{key}' of token {self.token.serial} through a generic "
                     f"token info write, the key is managed by the token.")
            raise PolicyError(f"The token info key '{key}' is managed by the token and can not be deleted.")
        self.remove_tokeninfo(key)

    def remove_tokeninfo(self, key: str = None) -> None:
        """
        Deletes the token info for the given key without checking whether the token class owns the key. If no key
        is given, all info entries from this token are deleted. This is the remover for server side code that
        maintains the token info of a token, a delete that comes from a request has to go through
        delete_tokeninfo().

        :param key: The key to delete, or None to delete every entry
        """
        statement = delete(TokenInfo).where(TokenInfo.token_id == self.token.id)
        if key:
            statement = statement.where(TokenInfo.Key == key)
        db.session.execute(statement)
        db.session.commit()

    def delete_tokengroup(self, tokengroup: str = None, tokengroup_id: int = None) -> bool:
        """
        Removes a token group from a token.
        You either need to specify the name or the ID of the tokengroup. If none of them is given, all token groups
        are removed from the token.

        :param tokengroup: The name of the tokengroup
        :param tokengroup_id: The ID of the tokengroup
        :return: True in case of success
        """
        statement = delete(TokenTokengroup).where(TokenTokengroup.token_id == self.token.id)
        if tokengroup_id:
            statement = statement.where(TokenTokengroup.tokengroup_id == tokengroup_id)
        elif tokengroup:
            group_stmt = select(Tokengroup).where(Tokengroup.name == tokengroup)
            tokengroup_db = db.session.execute(group_stmt).scalar_one_or_none()
            if not tokengroup_db:
                log.warning("Tokengroup %s does not exist. Cannot remove it from token %s.", tokengroup,
                            self.get_serial())
                raise ResourceNotFoundError(_("Tokengroup {0!s} does not exist.").format(tokengroup))
            statement = statement.where(TokenTokengroup.tokengroup_id == tokengroup_db.id)
        db.session.execute(statement)
        db.session.commit()
        return True

    @check_token_locked
    def set_count_auth_success_max(self, count):
        """
        Sets the counter for the maximum allowed successful logins
        as key "count_auth_success_max" in token info

        :param count: a number
        :type count: int
        """
        self.write_tokeninfo("count_auth_success_max", int(count))

    @check_token_locked
    def set_count_auth_success(self, count):
        """
        Sets the counter for the occurred successful logins
        as key "count_auth_success" in token info

        :param count: a number
        :type count: int
        """
        self.write_tokeninfo("count_auth_success", int(count))

    @check_token_locked
    def set_count_auth_max(self, count):
        """
        Sets the counter for the maximum allowed login attempts
        as key "count_auth_max" in token info

        :param count: a number
        :type count: int
        """
        self.write_tokeninfo("count_auth_max", int(count))

    @check_token_locked
    def set_count_auth(self, count):
        """
        Sets the counter for the occurred login attepms
        as key "count_auth" in token info

        :param count: a number
        :type count: int
        """
        self.write_tokeninfo("count_auth", int(count))

    def get_count_auth_success_max(self):
        """
        Return the maximum allowed successful authentications
        """
        ret = int(self.get_tokeninfo("count_auth_success_max", 0))
        return ret

    def get_count_auth_success(self):
        """
        Return the number of successful authentications
        """
        ret = int(self.get_tokeninfo("count_auth_success", 0))
        return ret

    def get_count_auth_max(self):
        """
        Return the number of maximum allowed authentications
        """
        ret = int(self.get_tokeninfo("count_auth_max", 0))
        return ret

    def get_count_auth(self):
        """
        Return the number of all authentication tries
        """
        ret = int(self.get_tokeninfo("count_auth", 0))
        return ret

    def get_validity_period_end(self):
        """
        Returns the end of validity period (if set).
        If it is not set, "" is returned.

        :return: the end of the validity period
        :rtype: str
        """
        end = self.get_tokeninfo("validity_period_end", "")
        if end:
            end = parse_legacy_time(end)
        return end

    @check_token_locked
    def set_validity_period_end(self, end_date):
        """
        sets the end date of the validity period for a token

        :param end_date: the end date in the format YYYY-MM-DDTHH:MM+OOOO
                         if the format is wrong, the method will
                         throw an exception
        :type end_date: str
        """
        if not end_date:
            self.remove_tokeninfo("validity_period_end")
        else:
            #  upper layer will catch. we just try to verify the date format
            try:
                d = parse_date_string(end_date)
            except ValueError as _e:
                log.debug(f'{traceback.format_exc()!s}')
                raise TokenAdminError('Could not parse validity period end date!')
            self.write_tokeninfo("validity_period_end", d.strftime(DATE_FORMAT))

    def get_validity_period_start(self):
        """
        returns the start of validity period (if set)
        if not set, "" is returned.

        :return: the start of the validity period
        :rtype: str
        """
        start = self.get_tokeninfo("validity_period_start", "")
        if start:
            start = parse_legacy_time(start)
        return start

    @check_token_locked
    def set_validity_period_start(self, start_date):
        """
        sets the start date of the validity period for a token

        :param start_date: the start date in the format YYYY-MM-DDTHH:MM+OOOO
                           if the format is wrong, the method will
                           throw an exception
        :type start_date: str
        """
        if not start_date:
            self.remove_tokeninfo("validity_period_start")
        else:
            try:
                d = parse_date_string(start_date)
            except ValueError as _e:
                log.debug(f'{traceback.format_exc()!s}')
                raise TokenAdminError('Could not parse validity period start date!')

            self.write_tokeninfo("validity_period_start", d.strftime(DATE_FORMAT))

    @check_token_locked
    def set_next_pin_change(self, diff=None, password=False):
        """
        Sets the timestamp for the next_pin_change. Provide a
        difference like 90d (90 days).

        :param diff: The time delta.
        :type diff: basestring
        :param password: Do no set next_pin_change but next_password_change
        :return: None
        """
        days = int(diff.lower().strip("d"))
        key = "next_pin_change"
        if password:
            key = "next_password_change"
        new_date = datetime.now(tzlocal()) + timedelta(days=days)
        self.write_tokeninfo(key, new_date.strftime(DATE_FORMAT))

    def is_pin_change(self, password=False):
        """
        Returns true if the pin of the token needs to be changed.

        :param password: Whether the password needs to be changed.
        :type password: bool
        :return: True or False
        """
        key = "next_pin_change"
        if password:
            key = "next_password_change"
        sdate = self.get_tokeninfo(key)
        date_change = parse_date_string(parse_legacy_time(sdate))
        return datetime.now(tzlocal()) > date_change

    @check_token_locked
    def inc_count_auth_success(self):
        """
        Increase the counter, that counts successful authentications
        Also increase the auth counter
        """
        succcess_counter = self.get_count_auth_success()
        succcess_counter += 1
        auth_counter = self.get_count_auth()
        auth_counter += 1
        self.add_tokeninfo_dict({"count_auth_success": int(succcess_counter),
                                 "count_auth": int(auth_counter)})
        return succcess_counter

    @check_token_locked
    def post_success(self):
        """
        Run anything after a token was used for successful authentication
        """
        return

    @check_token_locked
    def inc_count_auth(self):
        """
        Increase the counter, that counts authentications - successful and
        unsuccessful
        """
        count = self.get_count_auth()
        count += 1
        self.set_count_auth(count)
        return count

    def check_reset_failcount(self):
        """
        Checks if we should reset the failcounter due to the
        FAILCOUNTER_CLEAR_TIMEOUT

        :return: True, if the failcounter was reset
        """
        timeout = 0
        try:
            timeout = int(get_from_config(FAILCOUNTER_CLEAR_TIMEOUT, 0))
        except Exception as exx:
            log.warning("Misconfiguration. Error retrieving "
                        "failcounter_clear_timeout: "
                        f"{exx!s}")
        if timeout and self.token.failcount == self.get_max_failcount():
            now = datetime.now(tzlocal())
            lastfail = self.get_tokeninfo(FAILCOUNTER_EXCEEDED)
            if lastfail is not None:
                failcounter_exceeded = parse_legacy_time(lastfail, return_date=True)
                if now > failcounter_exceeded + timedelta(minutes=timeout):
                    self.reset()
                    return True
        return False

    def check_failcount(self):
        """
        Checks if the failcounter is exceeded. It returns True, if the
        failcounter is less than maxfail

        :return: True or False
        :rtype: bool
        """
        return self.token.failcount < self.token.maxfail

    def check_auth_counter(self):
        """
        This function checks the count_auth and the count_auth_success.
        If the counters are less or equal than the maximum allowed counters
        it returns True. Otherwise, False.

        :return: success if the counter is less than max
        :rtype: bool
        """
        count_auth = self.get_count_auth()
        count_auth_max = self.get_count_auth_max()
        count_auth_success = self.get_count_auth_success()
        count_auth_success_max = self.get_count_auth_success_max()
        if count_auth_max != 0 and count_auth >= count_auth_max:
            return False

        if count_auth_success_max != 0 and count_auth_success >= count_auth_success_max:
            return False

        return True

    def check_validity_period(self):
        """
        This checks if the datetime.now() is within the validity
        period of the token.

        :return: success
        :rtype: bool
        """
        start = self.get_validity_period_start()
        end = self.get_validity_period_end()

        if start:
            dt_start = parse_legacy_time(start, return_date=True)
            if dt_start > datetime.now(tzlocal()):
                return False

        if end:
            dt_end = parse_legacy_time(end, return_date=True)
            if dt_end < datetime.now(tzlocal()):
                return False

        return True

    def check_all(self, message_list):
        """
        Perform all checks on the token. Returns False if the token is either:
        * auth counter exceeded
        * not active
        * fail counter exceeded
        * validity period exceeded

        This is used in the function token.check_token_list

        The first failing check also records its machine-readable
        :class:`~privacyidea.lib.conditional_access.authentication_event_types.AuthEventReason` on
        ``self.auth_details``, so the authentication log can say *why* a token was unusable rather than only that it
        was. Both come from one table below, so the message and the reason can never drift apart.

        :param message_list: A list of messages
        :return: False, if any of the checks fail
        """
        checks = (
            # Check if the max auth is succeeded
            (self.check_auth_counter, "Authentication counter exceeded",
             AuthEventReason.TOKEN_AUTH_COUNTER_EXCEEDED),
            # Check if the token is disabled
            (self.is_active, "Token is disabled", AuthEventReason.TOKEN_DISABLED),
            (self.check_failcount, "Failcounter exceeded", AuthEventReason.TOKEN_FAILCOUNT_EXCEEDED),
            (self.check_validity_period, "Outside validity period",
             AuthEventReason.TOKEN_OUTSIDE_VALIDITY_PERIOD),
            (lambda: self.rollout_state not in [RolloutState.CLIENTWAIT, RolloutState.VERIFY_PENDING],
             "Token is not yet enrolled", AuthEventReason.TOKEN_NOT_YET_ENROLLED),
        )
        for passes, message, reason in checks:
            if not passes():
                message_list.append(message)
                self.auth_details[AUTH_EVENT_REASON_KEY] = reason
                log.info(f"{message_list} {self.get_serial()}")
                return False
        return True

    @log_with(log)
    @check_token_locked
    def inc_otp_counter(self, counter=None, increment=1, reset=True):
        """
        Increase the otp counter and store the token in the database

        Before increasing the token.count the token.count can be set using the
        parameter counter.

        :param counter: if given, the token counter is first set to counter and then
                increased by increment
        :type counter: int
        :param increment: increase the counter by this amount
        :type increment: int
        :param reset: reset the failcounter if set to True
        :type reset: bool
        :return: the new counter value
        """
        reset_counter = False
        if counter:
            self.token.count = counter

        self.token.count += increment

        if reset is True and get_from_config("DefaultResetFailCount") == "True":
            reset_counter = True

        if (reset_counter and self.token.active and self.token.failcount <
                self.token.maxfail):
            self.set_failcount(0)

        # make DB persistent immediately, to avoid the re-usage of the counter
        self.token.save()
        return self.token.count

    def check_otp_exist(self, otp, window=None):
        """
        checks if the given OTP value is/are values of this very token.
        This is used to autoassign and to determine the serial number of
        a token.

        :param otp: the OTP value
        :param window: The look ahead window
        :type window: int
        :return: True or a value > 0 in case of success
        """
        return -1

    def is_previous_otp(self, otp, window=10):
        """
        checks if a given OTP value is a previous OTP value, that lies in the
        past or has a lower counter.

        This is used in case of a failed authentication to return the
        information, that this OTP values was used previously and is invalid.

        :param otp: The OTP value.
        :type otp: basestring
        :param window: A counter window, how far we should look into the past.
        :type window: int
        :return: bool
        """
        return False

    def split_pin_pass(self, passw, user=None, options=None):
        """
        Split the password into the token PIN and the OTP value

        take the given password and split it into the PIN and the
        OTP value. The splitting can be dependent of certain policies.
        The policies may depend on the user.

        Each token type may define its own way to slit the PIN and
        the OTP value.

        :param passw: the password to split
        :return: tuple of pin and otp value
        :param user: The user/owner of the token
        :type user: User object
        :param options: can be used be the token types.
        :type options: dict
        :return: tuple of (split status, pin, otp value)
        :rtype: tuple
        """
        # The database field is always an integer
        otp_length = self.token.otplen
        log.debug(f"Splitting the OTP value of length {otp_length} from the password.")
        pin, otp_value = split_pin_pass(passw, otp_length, get_prepend_pin())
        # If the provided passw is shorter than the expected otp_length, we return the status False
        return len(passw) >= otp_length, pin, otp_value

    def status_validation_fail(self):
        """
        callback to enable a status change, if auth failed
        """
        return

    def status_validation_success(self):
        """
        callback to enable a status change, if auth succeeds
        """
        return

    def __repr__(self):
        """
        return the token state as text

        :return: token state as string representation
        :rtype:  string
        """
        return f"<{self.__class__!r} {redacted_attributes(self)!r}>"

    def get_init_detail(self, params=None, user=None):
        """
        to complete the token initialization, the response of the initialization
        should be built by this token specific method.
        This method is called from api/token after the token is enrolled

        get_init_detail returns additional information after an admin/init
        like the QR code of an HOTP/TOTP token.
        Can be anything else.

        :param params: The request params during token creation token/init
        :type params: dict
        :param user: the user, token owner
        :type user: User object
        :return: additional descriptions
        :rtype: dict
        """
        response_detail = {}

        init_details = self.get_init_details()
        response_detail.update(init_details)
        response_detail['serial'] = self.get_serial()

        otpkey = None
        if 'otpkey' in init_details:
            otpkey = init_details.get('otpkey')

        if otpkey is not None:
            response_detail["otpkey"] = {"description": "OTP seed",
                                         "value": f"seed://{otpkey!s}",
                                         "img": create_img(otpkey)}

        return response_detail

    # challenge interfaces starts here
    @challenge_response_allowed
    def is_challenge_request(self, passw, user=None, options=None):
        """
        This method checks, if this is a request, that triggers a challenge.

        The default behaviour to trigger a challenge is,
        if the ``passw`` parameter only contains the correct token pin *and*
        the request contains a ``data`` or a ``challenge`` key i.e. if the
        ``options`` parameter contains a key ``data`` or ``challenge``.

        Each token type can decide on its own under which condition a challenge
        is triggered by overwriting this method.

        .. note:: in case of ``pin policy == 2`` (no pin is required)
                  the ``check_pin`` would always return true! Thus, each request
                  containing a ``data`` or ``challenge`` would trigger a challenge!

        The Challenge workflow is like this.

        When an authentication request is issued, first it is checked if this is
        a request which will create a new challenge (is_challenge_request) or if
        this is a response to an existing challenge (is_challenge_response).
        In these two cases during request processing the following functions are
        called::

            is_challenge_request or is_challenge_response  <-------+
                     |                       |                     |
                     V                       V                     |
            create_challenge        check_challenge_response     create_challenge
                     |                       |                     ^
                     |                       |                     |
                     |              has_further_challenge [yes] ---+
                     |                      [no]
                     |                       |
                     V                       V
            challenge_janitor       challenge_janitor

        :param passw: password, which might be the pin or pin+otp
        :type passw: string
        :param user: The user from the authentication request
        :type user: User object
        :param options: dictionary of additional request parameters
        :type options: dict
        :return: true or false
        :rtype: bool
        """
        request_is_challenge = False
        options = options or {}
        pin_match = self.check_pin(passw, user=user, options=options)
        if pin_match is True:
            request_is_challenge = True

        return request_is_challenge

    def is_challenge_response(self, passw, user=None, options=None):
        """
        This method checks, if this is a request that is supposed to be
        the answer to a previous challenge.

        The default behaviour to check if this is the response to a
        previous challenge is simply by checking if the request contains
        a parameter ``state`` or ``transactionid`` i.e. checking if the
        ``options`` parameter contains a key ``state`` or ``transactionid``.

        This method does not try to verify the response itself!
        It only determines, if this is a response for a challenge or not.
        If the challenge still exists, is checked in has_db_challenge_response.
        The response is verified in check_challenge_response.

        :param passw: password, which might be pin or pin+otp
        :type passw: string
        :param user: the requesting user
        :type user: User object
        :param options: dictionary of additional request parameters
        :type options: dict
        :return: true or false
        :rtype: bool
        """
        options = options or {}
        transaction_id = options.get("transaction_id") or options.get("state")
        return bool(transaction_id)

    def has_db_challenge_response(self, passw, user=None, options=None):
        """
        This method checks, if the given transaction_id is actually the response to
        a real challenge. To do so, it verifies, if there is a DB entry for the
        given serial number and transaction_id.
        This is to avoid side effects by passing non-existent transaction_ids.

        This method checks, if the token still has a challenge

        :param passw:
        :param user:
        :param options:
        :return:
        """
        options = options or {}
        challenge_response = False
        transaction_id = options.get("transaction_id") or options.get("state")
        if transaction_id:
            # Now we also need to check, if there is a corresponding DB entry
            chals = get_challenges(serial=self.token.serial, transaction_id=transaction_id)
            challenge_response = bool(chals)
            # Note whether they have all lapsed, for the authentication log: this is the last point at which they
            # exist, since checking the answer ends in challenge_janitor(), which deletes the expired ones. Recorded
            # here rather than asked again later, so the log costs no extra challenge query. Nothing to note when the
            # transaction holds none at all - with the Redis backend a long-expired challenge is already evicted, and
            # "no challenge here" is then what the log should say.
            if chals and all(not chal.is_valid() for chal in chals):
                self.auth_details[CHALLENGE_LAPSED_KEY] = True

        return challenge_response

    @check_token_locked
    def check_challenge_response(self, user=None, passw=None, options=None):
        """
        This method verifies if there is a matching challenge for the given
        passw and also verifies if the response is correct.

        It then returns the new otp_counter of the token.

        In case of success the otp_counter will be >= 0.

        :param user: the requesting user
        :type user: User object
        :param passw: the password (pin+otp)
        :type passw: string
        :param options: additional arguments from the request, which could
                        be token specific. Usually "transactionid"
        :type options: dict
        :return: return otp_counter. If -1, challenge does not match
        :rtype: int
        """
        options = options or {}
        otp_counter = -1

        # fetch the transaction_id
        transaction_id = options.get('transaction_id')
        if transaction_id is None:
            transaction_id = options.get('state')

        # get the challenges for this transaction ID
        if transaction_id is not None:
            challenges = get_challenges(serial=self.token.serial, transaction_id=transaction_id)

            for challenge in challenges:
                if challenge.is_valid():
                    # challenge is still valid
                    # Add the challenge to the options for check_otp
                    options["challenge"] = challenge.challenge
                    options["data"] = challenge.get_data()
                    if challenge.session == ChallengeSession.ENROLLMENT:
                        self.enroll_via_validate_2nd_step(passw, options=options)
                        challenge.delete()
                        # Basically we have a successfully answered challenge
                        otp_counter = 0
                    else:
                        # Now see if the OTP matches:
                        try:
                            otp_counter = self.check_otp(passw, options=options)
                        except ParameterError as e:
                            # ParameterError can be expected because options does not contain the data for every token
                            # type to do a successful check. This is the case if the user has multiple token, e.g.
                            # push and passkey, and uses push. In the final call with the push token, there is obviously
                            # no data for the passkey in the options
                            log.debug(e)
                            otp_counter = -1
                        if otp_counter >= 0:
                            # We found the matching challenge, so lets return the
                            # successful result and delete the challenge object.
                            challenge.delete()
                            break
                        else:
                            # increase the received_count
                            challenge.set_otp_status()

        self.challenge_janitor()
        return otp_counter

    # TODO: Add policy decorator like (challenge_response_allowed),
    #  that does a PIN reset, if there is no further challenge
    def has_further_challenge(self, options=None):
        """
        Returns true, if a token requires more than one challenge during challenge response
        authentication. This could be a 4eyes token or indexed secret token, that queries more
        than on input.

        :param options: Additional options from the request
        :return: True, if this very token requires further challenges
        """
        return False

    def challenge_janitor(self):
        """
        Clean up all challenges for this token, for which the expiration has
        expired.

        :return: None
        """
        cleanup_challenges(self.token.serial)

    def create_challenge(self, transactionid=None, options=None):
        """
        This method creates a challenge, which is submitted to the user.
        The submitted challenge will be preserved in the challenge
        database.

        If no transaction id is given, the system will create a transaction
        id and return it, so that the response can refer to this transaction.

        :param transactionid: the id of this challenge
        :param options: the request context parameters / data
        :type options: dict
        :return: tuple of (bool, message, transactionid, reply_dict)
        :rtype: tuple

        The return tuple builds up like this:
        ``bool`` if submit was successful;
        ``message`` which is displayed in the JSON response;
        additional challenge ``reply_dict``, which are displayed in the JSON challenges response.
        """
        options = options or {}
        message = options.get(PolicyAction.CHALLENGETEXT, _('please enter otp: ')).replace(r"\,", ",")

        data = None
        reply_dict = {}

        validity = int(get_from_config('DefaultChallengeValidityTime', 120))
        tokentype = self.get_tokentype().lower()
        # Maybe there is a HotpChallengeValidityTime...
        lookup_for = tokentype.capitalize() + 'ChallengeValidityTime'
        validity = int(get_from_config(lookup_for, validity))

        # Create the challenge (Redis if available, DB fallback)
        from privacyidea.lib.token import create_challenge as _create_challenge
        db_challenge = _create_challenge(self.token.serial,
                                         transaction_id=transactionid,
                                         challenge=options.get("challenge"),
                                         data=data,
                                         session=options.get("session"),
                                         validitytime=validity)
        self.challenge_janitor()
        return True, message, db_challenge.transaction_id, reply_dict

    def get_as_dict(self):
        """
        This returns the token data as a dictionary.
        It is used to display the token list at /token/list.

        :return: The token data as dict
        :rtype: dict
        """
        # first get the database values as dict
        token_dict = self.token.get()

        return token_dict

    @classmethod
    def api_endpoint(cls, request, g):
        """
        This provides a function to be plugged into the API endpoint
        /ttype/<tokentype> which is defined in api/ttype.py

        The method should return
            return "json", {}
        or
            return "text", "OK"

        :param request: The Flask request
        :param g: The Flask global object g
        :return: Flask Response or text
        """
        raise ParameterError(f"{cls.get_tokentype()!s} does not support the API endpoint")

    @staticmethod
    def test_config(params=None):
        """
        This method is used to test the token config. Some tokens require some
        special token configuration like the SMS-Token or the Email-Token.
        To test this configuration, this classmethod is used.

        It takes token specific parameters and returns a tuple of a boolean
        and a result description.

        :param params: token specific parameters
        :type params: dict
        :return: success, description
        :rtype: tuple
        """
        return False, "Not implemented"

    @staticmethod
    def get_setting_type(key):
        """
        This function returns the type of the token specific config/setting.
        This way a tokenclass can define settings, that can be "public" or a
        "password". If this setting is written to the database, the type of
        the setting is set automatically in set_privacyidea_config

        The key name needs to start with the token type.

        :param key: The token specific setting key
        :return: A string like "public"
        """
        return ""

    @classmethod
    def get_default_settings(cls, g, params):
        """
        This method returns a dictionary with default settings for token
        enrollment.
        These default settings depend on the token type and the defined
        policies.

        The returned dictionary is added to the parameters of the API call.

        :param g: context object, see documentation of ``Match``
        :param params: The call parameters
        :type params: dict
        :return: default parameters
        """
        return cls._get_default_settings(g)

    @classmethod
    def _get_default_settings(cls, g, role="user", username=None, userrealm=None,
                              adminuser=None, adminrealm=None):
        """
        Internal function that can be called either during enrollment via /token/init or during
        enrollment via validate/check.
        This way we have consistent policy handling.
        """
        return {}

    def check_last_auth_newer(self, last_auth):
        """
        Check if the last successful authentication with the token is newer
        than the specified time delta which is passed as 10h, 7d or 1y.

        It returns True, if the last authentication with this token is
        **newer** than the specified delta or by any chance exactly the same.

        It returns False, if the last authentication is older or
        if the data in the token can not be parsed.

        :param last_auth: 10h, 7d or 1y
        :type last_auth: basestring
        :return: bool
        """
        # By default, we return True
        res = True
        # The tdelta in the policy
        tdelta = parse_timedelta(last_auth)

        # The last successful authentication of the token
        date_s = self.get_tokeninfo(PolicyAction.LASTAUTH)
        if date_s:
            log.debug("Compare the last successful authentication of "
                      f"token {self.token.serial} with policy "
                      f"tdelta {tdelta}: {date_s}")
            # parse the string from the database
            try:
                last_success_auth = parse_date_string(date_s)
            except ParserError:
                log.info(f"Failed to parse the date in 'last_auth' of token {self.token.serial!s}.")
                return False

            if not last_success_auth.tzinfo:
                # the date string has no timezone, default timezone is UTC
                # We need to set the timezone manually
                last_success_auth = last_success_auth.replace(tzinfo=tzutc())
            # The last auth is to far in the past
            if last_success_auth + tdelta < datetime.now(tzlocal()):
                res = False
                log.debug("The last successful authentication is too old: "
                          f"{last_success_auth!s}")

        return res

    def generate_symmetric_key(self, server_component, client_component,
                               options=None):
        """
        This method generates a symmetric key, from a server component and a
        client component.
        This key generation could be based on HMAC, KDF or even Diffie-Hellman.

        The basic key-generation is simply replacing the last n byte of the
        server component with bytes of the client component.

        :param server_component: The component usually generated by privacyIDEA.
                                 This is a hex string
        :type server_component: str
        :param client_component: The component usually generated by the
            client (e.g. smartphone). This is a hex string.
        :type client_component: str
        :param options:
        :return: the new generated key as hex string
        :rtype: str
        """
        if len(server_component) <= len(client_component):
            raise Exception("The server component must be longer than the "
                            "client component.")

        key = server_component[:-len(client_component)] + client_component
        return key

    @staticmethod
    def get_import_csv(row):
        """
        Read the list from a csv file and return a dictionary, that can be used
        to do a token_init.

        :param row: The list of the line of a csv file
        :type row: list
        :return: A dictionary of init params
        """
        # The OTPKey is at the second column
        key = row[1].strip()
        if len(key) == 64:
            hashlib = "sha256"
        elif len(key) == 128:
            hashlib = "sha512"
        elif len(key) == 56:
            hashlib = "sha224"
        elif len(key) == 96:
            hashlib = "sha384"
        else:
            hashlib = "sha1"

        params = {"serial": row[0].strip(),
                  "hashlib": hashlib,
                  "otpkey": key,
                  "type": row[2].strip()}

        # get OTP len
        if len(row) >= 4:
            params["otplen"] = row[3].strip()
        else:
            params["otplen"] = 6

        return params

    def prepare_verify_enrollment(self, options=None):
        """
        This is called, if the token should be enrolled in a way, that the user
        needs to provide a proof, that the server can verify, that the token
        was successfully enrolled. E.g. with HOTP tokens the user might need to provide
        a correct OTP value.

        The returned dictionary is added to the response in "detail" -> "verify".

        :return: A dictionary with information that is needed to trigger the verification.
        """
        return None

    def verify_enrollment(self, response):
        """
        This is called during the 2nd step of the verified enrollment.
        This method verifies the actual response from the user.
        Returns true, if the verification was successful.

        :param response: The response given by the user
        :return: True
        """
        return False

    @classmethod
    def enroll_via_validate(cls, g, content, user_obj, message=None):
        """
        This class method is used in the policy ENROLL_VIA_MULTICHALLENGE.
        It enrolls a new token of this type and returns the necessary information
        to the client by modifying the content.

        :param g: context object
        :param content: The content of a response
        :param user_obj: A user object
        :param message: An alternative message displayed to the user during enrollment
        :return: None, the content is modified
        """
        return True

    def enroll_via_validate_2nd_step(self, passw, options=None):
        """
        This method is the optional second step of ENROLL_VIA_MULTICHALLENGE.
        It is used in situations like the email token, sms token or push,
        when enrollment via challenge response needs two steps.

        :param options:
        :return:
        """
        return True

    def _to_dict(self, b32=False):
        """
        export the token information to a dictionary.

        This can be used to re-encrypt tokens.

        :param b32: Export otp key b32encoded

        :return: a dict, containing the token and the tokeninfo
        """
        token_dict = {
            "serial": self.get_serial(),
            "type": self.get_type(),
            "otpkey": self.token.get_otpkey().getKey(),
            "description": self.token.description,
            "otplen": self.get_otplen(),
            "maxfail": self.get_max_failcount(),
            "failcount": self.get_failcount(),
            "counter": self.get_otp_count(),
            "window": self.get_otp_count_window(),
            "active": self.is_active(),
            "revoked": self.token.revoked,
            "locked": self.token.locked,
            "rollout_state": self.token.rollout_state,
            "_hashed_pin": self.token.pin_hash
        }
        if b32:
            token_dict["otpkey"] = b32encode(unhexlify(token_dict.get("otpkey")))
        token_dict["otpkey"] = to_unicode(token_dict.get("otpkey"))
        token_dict["info_list"] = self.get_tokeninfo(decrypted=True)
        return token_dict

    @classmethod
    def is_multichallenge_enrollable(cls):
        return False

    def get_enroll_url(self, user: User, params: dict):
        """
        Return the URL to enroll this token. It is not supported by all token types.
        """
        return None

    def export_token(self, export_user: bool = False) -> dict:
        """
        Create a dictionary with the token information that can be exported.
        """
        token_dict = self._to_dict()
        token_dict['issuer'] = 'privacyIDEA'
        if export_user and self.token.first_owner:
            token_dict["user"] = self.user.user_export_dict()

        return token_dict

    def import_token(self, token_information: dict):
        """
        Import a given token.
        """
        self.token.set_otpkey(token_information.setdefault("otpkey", ''))
        self.token.otplen = int(token_information.setdefault("otplen", 6))
        self.token.description = token_information.setdefault("description", '')
        self.token.pin_hash = token_information.setdefault("_hashed_pin", None)
        self.add_tokeninfo_dict(token_information.setdefault("info_list", {}))
        self.write_tokeninfo("import_date", datetime.now(timezone.utc).isoformat(timespec="seconds"))
        self.save()
