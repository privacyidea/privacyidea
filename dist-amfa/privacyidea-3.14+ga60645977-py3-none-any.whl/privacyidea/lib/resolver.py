#  privacyIDEA is a fork of LinOTP
#
#  2018-12-14 Cornelius Kölbel <cornelius.koelbel@netknights.it>
#             Add censor-password functionality
#  2016-04-08 Cornelius Kölbel <cornelius@privacyidea.org>
#             simplify repetetive unequal checks
#
#  Nov 27, 2014 Cornelius Kölbel <cornelius@privacyidea.org>
#               Migration to flask
#               Rewrite of methods
#               100% test code coverage
#
#  May 08, 2014 Cornelius Kölbel
#  License:  AGPLv3
#  contact:  http://www.privacyidea.org
#
#  Copyright (C) 2010 - 2014 LSE Leading Security Experts GmbH
#  License:  AGPLv3
#  contact:  http://www.linotp.org
#            http://www.lsexperts.de
#            linotp@lsexperts.de
#
# This code is free software; you can redistribute it and/or
# modify it under the terms of the GNU AFFERO GENERAL PUBLIC LICENSE
# License as published by the Free Software Foundation; either
# version 3 of the License, or any later version.
#
# This code is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU AFFERO GENERAL PUBLIC LICENSE for more details.
#
# You should have received a copy of the GNU Affero General Public
# License along with this program.  If not, see <http://www.gnu.org/licenses/>.
#
"""
This is the library for creating new resolvers in the database and
deleting existing ones.
Also can create a resolver object of a class like LDAP, SQL or Passwd.

Its only dependencies are to the database model.py and to the
config.py, so this can be tested standalone without realms, tokens and
webservice!
"""
import copy
import json
import logging
from typing import Any

from sqlalchemy import func, delete, select

from privacyidea.lib.cache.user import invalidate_resolver
from privacyidea.lib.framework import get_request_local_store
from privacyidea.lib.usercache import delete_user_cache
from privacyidea.lib.utils import (sanity_name_check, get_data_from_params,
                                   is_true)
from privacyidea.lib.utils.export import (register_import, register_export)
from .config import (get_resolver_types, get_resolver_classes, get_config_object)
from .crypto import encryptPassword, CENSORED
from .error import ConfigAdminError
from .log import log_with
from privacyidea.lib.params import get_required
from ..models import (Resolver,
                      ResolverConfig, save_config_timestamp, db)

log = logging.getLogger(__name__)


# Hide the keyswords BINDPW and Password in params
@log_with(log)
def save_resolver(params):
    """
    create a new resolver from request parameters
    and save the resolver in the database.

    If the resolver already exist, it is updated.
    If you update a resolver, you do not need to provide all parameters.
    Parameters you do not provide are left untouched.
    When updating a resolver you must not change the type!
    You do not need to specify the type, but if you specify a wrong type,
    it will produce an error.

    :param params: request parameters like "name" and "type" and the
                   configuration parameters of the resolver config.
    :type params: dict
    :return: the database ID of the resolver
    :rtype: int
    """
    # before we create the resolver in the database, we need to check
    # for the name and type thing...
    resolvername = get_required(params, 'resolver')
    resolvertype = get_required(params, 'type')
    update_resolver = False
    # check the name
    sanity_name_check(resolvername)
    # check the type
    resolvertypes = get_resolver_types()
    if resolvertype not in resolvertypes:
        raise Exception(f"resolver type : {resolvertype!s} not in {str(resolvertypes)!s}")

    # check the name
    resolvers = get_resolver_list(filter_resolver_name=resolvername)
    for r_name, resolver in resolvers.items():
        if resolver.get("type") == resolvertype:
            # We found the resolver with the same name and the same type,
            # So we will update this resolver
            update_resolver = True
        else:
            raise Exception("resolver with similar name and other type already "
                            f"exists: {r_name}")

    # create a dictionary for the ResolverConfig
    resolver_config = get_resolver_config_description(resolvertype)
    config_description = resolver_config.get(resolvertype).get('config', {})

    data, types, desc = get_data_from_params(params, ['resolver', 'type'],
                                             config_description, resolvertype,
                                             resolvername)

    # Everything passed. So lets actually create the resolver in the DB
    resolver = None
    if update_resolver:
        resolver_stmt = select(Resolver).where(func.lower(Resolver.name) == resolvername.lower())
        resolver = db.session.scalar(resolver_stmt)
    if resolver is not None:
        resolver_id = resolver.id
    else:
        # Either this is a new resolver, or the cached configuration reported it
        # as existing while it is no longer in the database (e.g. a stale config
        # object after a delete). In both cases we (re-)create it.
        resolver = Resolver(params.get("resolver"),
                            params.get("type"))
        db.session.add(resolver)
        db.session.flush()
        resolver_id = resolver.id
    # create the config
    for key, value in data.items():
        if not value and not isinstance(value, bool):
            # If the value is empty, we do not store it. But we check if an old entry already exists and delete it.
            old_config = delete(ResolverConfig).filter_by(resolver_id=resolver_id, Key=key)
            db.session.execute(old_config)
            continue
        if types.get(key) == "password":
            if value == CENSORED:
                stored_stmt = select(ResolverConfig).filter_by(resolver_id=resolver_id, Key=key)
                stored_config = db.session.scalar(stored_stmt)
                if not stored_config or stored_config.Type == "password":
                    # Keep the stored secret
                    continue
                # Stored in plain text before the resolver class declared the entry a password: encrypt it now
                value = encryptPassword(stored_config.Value)
            else:
                value = encryptPassword(value)
        elif types.get(key) == "dict_with_password":
            resolver_data_types = resolver_config.get(resolvertype, {}).get("config")
            if not isinstance(value, dict):
                log.warning("Config entry %s is not a dict. Cannot be stored.", key)
                continue
            for (dict_key, dict_value) in value.items():
                if resolver_data_types.get(f"{key}.{dict_key}") == "password":
                    if dict_value == CENSORED:
                        # Fetch the old value from the database to not delete the password from the config
                        dict_stmt = select(ResolverConfig).filter_by(resolver_id=resolver_id, Key=key)
                        old_dict_serialized = db.session.scalar(dict_stmt)
                        if old_dict_serialized:
                            old_dict = json.loads(old_dict_serialized.Value)
                            old_entry = old_dict.get(dict_key)
                            if old_entry:
                                value[dict_key] = old_entry  # It is already encrypted
                    else:
                        value[dict_key] = encryptPassword(dict_value)

        if isinstance(value, dict):
            value = json.dumps(value)

        existing_config_stmt = select(ResolverConfig).filter(ResolverConfig.resolver_id == resolver_id,
                                                             ResolverConfig.Key == key)
        existing_config = db.session.execute(existing_config_stmt).scalar_one_or_none()
        if existing_config:
            # Update existing entry
            existing_config.Value = value
            existing_config.Type = types.get(key, "")
            existing_config.Description = desc.get(key, "")
        else:
            config = ResolverConfig(resolver_id=resolver_id,
                                    Key=key,
                                    Value=value,
                                    Type=types.get(key, ""),
                                    Description=desc.get(key, ""))
            db.session.add(config)

    # Remove corresponding entries from the user cache
    delete_user_cache(resolver=resolvername)
    save_config_timestamp()
    db.session.commit()

    # Only now that the new configuration is committed and the timestamp says so.
    # Dropping the shared entries earlier leaves a window in which another worker
    # is still serving the previous configuration, misses the cache, and fills it
    # again from what it is still holding - and those entries would then outlive
    # the change by a full TTL.
    if not invalidate_resolver(resolvername):
        # Redis could not be asked, so entries cached under the previous configuration may still
        # be served until they expire. Nothing here can undo that, but an operator whose change
        # did not take effect at once has to be able to find out why.
        log.warning(f"The cached user entries of the resolver {resolvername!r} could not be "
                    f"dropped. Entries from the previous configuration may be served until they expire.")

    # Resolver TLS endpoints may have changed - drop cached cert health.
    from privacyidea.lib.health import invalidate_certificate_cache
    invalidate_certificate_cache()

    return resolver_id


@log_with(log, log_exit=False)
# @cache.memoize(10)
def get_resolver_list(filter_resolver_type=None,
                      filter_resolver_name=None,
                      editable=None,
                      censor=False):
    """
    Gets the list of configured resolvers from the database

    :param filter_resolver_type: Only resolvers of the given type are returned
    :type filter_resolver_type: basestring
    :param filter_resolver_name: Get the distinct resolver
    :type filter_resolver_name: basestring
    :param editable: Whether only return editable resolvers
    :type editable: bool
    :param censor: censor sensitive data. Each resolver class decides on its own,
        which data should be censored.
    :type censor: bool
    :rtype: Dictionary of the resolvers and their configuration
    """
    config_object = get_config_object()
    if censor:
        resolvers = copy.deepcopy(config_object.resolver)
    else:
        resolvers = config_object.resolver
    if filter_resolver_type:
        reduced_resolvers = {}
        for reso_name, reso in resolvers.items():
            if reso.get("type") == filter_resolver_type:
                reduced_resolvers[reso_name] = resolvers[reso_name]
        resolvers = reduced_resolvers
    if filter_resolver_name:
        reduced_resolvers = {}
        for reso_name in resolvers:
            if reso_name.lower() == filter_resolver_name.lower():
                reduced_resolvers[reso_name] = resolvers[reso_name]
        resolvers = reduced_resolvers
    if editable is not None:
        reduced_resolvers = {}
        if editable is True:
            for reso_name, reso in resolvers.items():
                check_editable = is_true(reso["data"].get("Editable")) or \
                                 is_true(reso["data"].get("EDITABLE"))
                if check_editable:
                    reduced_resolvers[reso_name] = resolvers[reso_name]
        elif editable is False:
            for reso_name, reso in resolvers.items():
                check_editable = is_true(reso["data"].get("Editable")) or \
                                 is_true(reso["data"].get("EDITABLE"))
                if not check_editable:
                    reduced_resolvers[reso_name] = resolvers[reso_name]
        resolvers = reduced_resolvers
    if censor:
        for reso_name, reso in resolvers.items():
            for censor_key in reso.get("censor_keys", []):
                if censor_key in reso["data"]:
                    reso["data"][censor_key] = CENSORED
                else:
                    # it might be a sub key
                    data = reso["data"]
                    keys = censor_key.split('.')
                    for key in keys[:-1]:
                        data = data[key]
                    data[keys[-1]] = CENSORED

    return resolvers


@log_with(log)
def delete_resolver(resolvername):
    """
    delete a resolver and all related ResolverConfig entries
    If there was no resolver, that could be deleted, it returns -1

    :param resolvername: the name of the to be deleted resolver
    :type resolvername: string
    :return: The Id of the resolver
    :rtype: int
    """
    ret = -1

    select_stmt = select(Resolver).where(Resolver.name == resolvername)
    resolver = db.session.execute(select_stmt).scalar_one_or_none()
    if resolver:
        if resolver.realm_list:
            # The resolver is still contained in a realm! We must not delete it
            realmname = resolver.realm_list[0].realm.name
            raise ConfigAdminError(f"The resolver {resolvername!r} is still contained in "
                                   f"realm {realmname!r}.")

        db.session.delete(resolver)
        save_config_timestamp()
        db.session.commit()
        ret = resolver.id
    # Delete resolver object from cache
    store = get_request_local_store()
    if 'resolver_objects' in store:
        if resolvername in store['resolver_objects']:
            del store['resolver_objects'][resolvername]

    # Remove corresponding entries from the user cache
    delete_user_cache(resolver=resolvername)
    if not invalidate_resolver(resolvername):
        # Redis could not be asked, so entries cached for a resolver that no longer exists may
        # still be served until they expire: until then a deleted user store can still resolve.
        log.warning(f"The cached user entries of the deleted resolver {resolvername!r} could not "
                    f"be dropped. Its users may still resolve until the entries expire.")

    # Resolver TLS endpoints may have changed - drop cached cert health.
    from privacyidea.lib.health import invalidate_certificate_cache
    invalidate_certificate_cache()

    return ret


@log_with(log, log_exit=False)
# @cache.memoize(10)
def get_resolver_config(resolvername):
    """
    return the complete config of a given resolver from the database
    :param resolvername: the name of the resolver
    :type resolvername: string
    :return: the config of the resolver
    :rtype: dict
    """
    reso = get_resolver_list(filter_resolver_name=resolvername)
    return reso.get(resolvername, {}).get("data", {})


@log_with(log)
# @cache.memoize(10)
def get_resolver_config_description(resolver_type):
    """
    get the configuration description of a resolver

    :param resolver_type: the type of the resolver. Something like
                          "passwdresolver".
    :type resolver_type: string
    :return: configuration description dict
             This should contain a key "config" that contains a dictionary
             and a key "clazz":
             {'passwdresolver': {'config': {'fileName': 'string'},
                                 'clazz': 'useridresolver.PasswdIdResolver'
                                          '.IdResolver'}}

    """
    descriptor = None
    resolver_class = get_resolver_class(resolver_type)

    if resolver_class is not None:
        descriptor = resolver_class.getResolverClassDescriptor()

    return descriptor


# @cache.memoize(10)
def get_resolver_class(resolver_type):
    """
    return the class object for a resolver type
    :param resolver_type: string specifying the resolver
                          fully qualified or abbreviated
    :return: resolver object class
    """
    ret = None
    resolver_clazzes = get_resolver_classes()
    for k in resolver_clazzes:
        if k.getResolverClassType() == resolver_type:
            ret = k
            break
    return ret


# @cache.memoize(10)
def get_resolver_type(resolvername):
    """
    return the type of a resolvername

    :param resolvername: THe name of the resolver
    :return: The type of the resolver
    :rtype: string
    """
    reso_list = get_resolver_list(filter_resolver_name=resolvername)
    r_type = reso_list.get(resolvername, {}).get("type")
    return r_type


@log_with(log)
# @cache.memoize(10)
def get_resolver_object(resolvername):
    """
    Return the cached resolver object for the given resolver name (stored in the request context).
    If no resolver object is cached, create it and add it to the cache.

    :param resolvername: the resolver string as from the token including
                         the config as last part
    :return: instance of the resolver with the loaded config

    """
    r_type = get_resolver_type(resolvername)
    r_obj_class = get_resolver_class(r_type)

    if r_obj_class is None:
        log.error(f"Can not find resolver with name {resolvername!s} ")
        return None
    else:
        store = get_request_local_store()
        if 'resolver_objects' not in store:
            store['resolver_objects'] = {}
        resolver_objects = store['resolver_objects']
        if resolvername not in resolver_objects:
            # create the resolver instance and load the config
            r_obj = resolver_objects[resolvername] = r_obj_class()
            if r_obj is not None:
                resolver_config = get_resolver_config(resolvername)
                r_obj.loadConfig(resolver_config)
                r_obj.name = resolvername
        return resolver_objects[resolvername]


def _replace_censored_values(params: dict[str, Any], old_config: dict[str, Any]):
    """
    Helper to replace censored values in params with the values from old_config.
    """
    for key in old_config.get("censor_keys", []):
        # Censored keys can be nested e.g. client_certificate.private_key_password
        layers = key.split('.')
        last_layer = params
        for nested_key in layers[:-1]:
            if not isinstance(last_layer, dict):
                # seems to be a wrong config, we cannot replace the censored value. So we continue with the next one
                break
            last_layer = last_layer.get(nested_key, {})
        if not isinstance(last_layer, dict):
            continue
        value = last_layer.get(layers[-1])
        if value == CENSORED:
            # Overwrite with the value from the database
            old_value = old_config.get("data", {})
            valid_value = True
            for layer_key in layers:
                if not isinstance(old_value, dict):
                    # we can not read the correct old value from the database
                    log.debug(
                        "Failed to replace censored value for %s, because no uncensored value exists in the database.",
                        key)
                    valid_value = False
                    break
                old_value = old_value.get(layer_key, {})
            if valid_value:
                last_layer[layers[-1]] = old_value


@log_with(log)
def pretestresolver(resolvertype, params):
    """
    This tests, if the params will create a working resolver.
    This function can be called before a resolver is created.

    :param resolvertype:
    :param params:
    :type params: dict
    :return:
    """
    # If an already saved resolver is tested again, the password
    # could be "__CENSORED__". In this case we use the old, saved password.
    if params.get("resolver"):
        old_config_list = get_resolver_list(filter_resolver_name=params.get("resolver")) or {}
        old_config = old_config_list.get(params.get("resolver")) or {}
        _replace_censored_values(params, old_config)

    # determine the class by the given type
    r_obj_class = get_resolver_class(resolvertype)
    (success, desc) = r_obj_class.testconnection(params)
    return success, desc


@register_export('resolver')
def export_resolver(name=None, censor=False):
    """ Export given or all resolver configuration """
    return get_resolver_list(filter_resolver_name=name, censor=censor)


@register_import('resolver', prio=10)
def import_resolver(data, name=None):
    """Import resolver configuration"""
    # TODO: Currently this functions does not check for the plausibility of the
    #  given data. We could use "pretestresolver() / testconnection()" (which
    #  doesn't check the input) or "loadConfig()" (which also doesn't check the
    #  parameter, at least for LDAP/SQL-resolver).
    log.debug(f'Import resolver config: {data!s}')

    # Check for old style export type where resolvers were given as a list
    if isinstance(data, list):
        data = {x.get("resolvername"): x for x in data}

    for res_name, res_data in data.items():
        if name and name != res_name:
            continue
        # remove the 'censor_keys' entry from data since it is not necessary
        res_data.pop('censor_keys', None)
        # save_resolver() needs the resolver name at key 'resolver'
        res_data['resolver'] = res_data.pop('resolvername')
        # also all the 'data' entries need to be in the first dict level
        res_data.update(res_data.pop('data'))
        rid = save_resolver(res_data)
        # TODO: we have no information if a new resolver was created or an
        #  existing resolver updated. We would need to enhance "save_resolver()".
        log.info('Import of resolver "{!s}" finished,'
                 ' id: {!s}'.format(res_data['resolver'], rid))
