#  2022-06-06 Cornelius Kölbel <cornelius.koelbel@netknights.it>
#             Fix recovery link
#  2015-01-06 Cornelius Kölbel <cornelius@privacyidea.org>
#             The Password reset functions
#
# This code is free software; you can redistribute it and/or
# modify it under the terms of the GNU AFFERO GENERAL PUBLIC LICENSE
# License as published by the Free Software Foundation; either
# version 3 of the License, or any later version.
#
# This code is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU AFFERO GENERAL PUBLIC LICENSE for more details.
#
# You should have received a copy of the GNU Affero General Public
# License along with this program.  If not, see <http://www.gnu.org/licenses/>.
#
#
import logging
from datetime import datetime, timezone

from sqlalchemy import select, delete

from privacyidea.lib.config import get_from_config
from privacyidea.lib.crypto import (hash_with_pepper, verify_with_pepper,
                                    generate_password)
from privacyidea.lib.error import UserError, PrivacyIDEAError, ConfigAdminError
from privacyidea.lib.log import log_with
from privacyidea.lib.policies.actions import PolicyAction
from privacyidea.lib.policy import SCOPE, Match
from privacyidea.lib.resolver import get_resolver_list
from privacyidea.lib.smtpserver import send_email_identifier
from privacyidea.models import PasswordReset, db

__doc__ = """
This is the library for creating a recovery code for password reset.
The recovery code is sent to the user.

The salted/peppered hash of the recovery code is stored in the passwordreset
database table.

This module is tested in tests/test_lib_passwordreset.py
"""

log = logging.getLogger(__name__)

BODY = """Someone requested to reset the password within privacyIDEA.

To reset your user password please visit the link

{0!s}/reset/{1!s}@{2!s}/{3!s}
"""


@log_with(log)
def create_recoverycode(user, email=None, expiration_seconds=3600,
                        recoverycode=None, base_url=""):
    """
    Create and send a password recovery code

    :param user: User for whom the password reset code should be sent
    :type user: User Object
    :param email: The optional email of the user
    :param recoverycode: Only used for testing purpose
    :return: bool
    """
    # Validate everything before persisting a recovery code, so a rejected
    # request never leaves a PasswordReset row behind.
    if not user:
        raise UserError("User required for recovery token.")
    user_email = user.get_specific_info(["email"]).get("email")
    if not user_email:
        raise UserError("The user has no email address on file. "
                        "Cannot send a password recovery code.")
    if email and email.lower() != user_email.lower():
        raise UserError("The email does not match the users email.")
    identifier = get_from_config("recovery.identifier")
    if not identifier:
        raise ConfigAdminError("Missing configuration "
                               "recovery.identifier.")

    # ``base_url`` is expected to be a trusted base URL (see
    # privacyidea.lib.framework.get_base_url); append the Web UI hashbang route
    # that consumes the recovery code.
    base_url = base_url.rstrip("/") + "/#!"
    recoverycode = recoverycode or generate_password(size=24)
    hash_code = hash_with_pepper(recoverycode)
    pwreset = PasswordReset(hash_code, username=user.login,
                            realm=user.realm,
                            expiration_seconds=expiration_seconds)
    pwreset.save()

    # send this recoverycode
    r = send_email_identifier(identifier, user_email,
                              "Your password reset",
                              BODY.format(base_url,
                                          user.login, user.realm,
                                          recoverycode))
    if not r:
        raise PrivacyIDEAError(f"Failed to send email. {r!s}")
    return True


@log_with(log)
def check_recoverycode(user, recoverycode):
    """
    Check if the given recovery code is a valid recovery code for this user

    :param user: User, who wants to reset his password.
    :type user: User object
    :param recoverycode: The recovery code
    :type recoverycode: str
    :return: True is code was correct
    """
    recoverycode_valid = False
    # delete old entries
    delete_expired_stmt = delete(PasswordReset).where(
        PasswordReset.expiration < datetime.now(timezone.utc).replace(tzinfo=None))
    delete_result = db.session.execute(delete_expired_stmt)
    log.debug(f"{delete_result.rowcount!s} old password recoverycodes deleted.")
    stmt = select(PasswordReset).where(PasswordReset.username == user.login, PasswordReset.realm == user.realm)
    pw_resets = db.session.scalars(stmt).all()
    for pwr in pw_resets:
        if verify_with_pepper(pwr.recoverycode, recoverycode):
            recoverycode_valid = True
            log.debug(f"Found valid recoverycode for user {user!r}")
            # Delete the recovery code, so that it can only be used once!
            r = pwr.delete()
            log.debug(f"{r!s} used password recoverycode deleted.")

    db.session.commit()
    return recoverycode_valid


@log_with(log)
def is_password_reset(g):
    """
    Check if password reset is allowed.

    We need to check, if a user policy with password_reset exists AND if an
    editable resolver exists. Otherwise password_reset does not make any sense.

    :return: True or False
    """
    rlist = get_resolver_list(editable=True)
    log.debug(f"Number of editable resolvers: {len(rlist)!s}")
    pwreset = Match.generic(g, scope=SCOPE.USER,
                            action=PolicyAction.PASSWORDRESET).allowed(write_to_audit_log=False)
    log.debug(f"Password reset allowed via policies: {pwreset!s}")
    return bool(rlist and pwreset)
