#  2020-09-24 Cornelius Kölbel <cornelius.koelbel@netknights.it>
#             Use Argon2
#  2017-08-11 Cornelius Kölbel <cornelius.koelbel@netknights.it>
#             initial writeup
#
#  License:  AGPLv3
#  contact:  http://www.privacyidea.org
#
# This code is free software; you can redistribute it and/or
# modify it under the terms of the GNU AFFERO GENERAL PUBLIC LICENSE
# License as published by the Free Software Foundation; either
# version 3 of the License, or any later version.
#
# This code is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNE7SS FOR A PARTICULAR PURPOSE.  See the
# GNU AFFERO GENERAL PUBLIC LICENSE for more details.
#
# You should have received a copy of the GNU Affero General Public
# License along with this program.  If not, see <http://www.gnu.org/licenses/>.
#
import datetime
import logging
import re

from passlib.exc import PasswordSizeError
from sqlalchemy import update, select, delete

from ..models import AuthCache, db
from ..models.utils import utc_now
from .cache import auth as redis_auth_cache
from .crypto import pass_hash, verify_pass_hash
from .utils import parse_timedelta

log = logging.getLogger(__name__)


def parse_auth_cache_value(value: str) -> tuple[datetime.timedelta, datetime.timedelta | None, int]:
    """
    Split the value of an ``auth_cache`` policy, like ``4h``, ``4h/5m`` or ``2m/3``.

    :param value: the policy value
    :return: how long after its first authentication an entry can be used, how long
        after its last one (``None`` if the policy does not limit that) and how often it
        can be used (``0`` for no limit)
    :raises TypeError: if a time in the value can not be parsed
    """
    auth_times = value.split("/")
    first_offset = parse_timedelta(auth_times[0])
    last_offset = None
    max_auths = 0
    if len(auth_times) == 2:
        if re.match(r"^\d+$", auth_times[1]):
            max_auths = int(auth_times[1])
        else:
            last_offset = parse_timedelta(auth_times[1])
    return first_offset, last_offset, max_auths


def get_idle_limit(value: str) -> datetime.timedelta:
    """
    How long an entry can go unused before an ``auth_cache`` policy with this value
    stops accepting it for good.

    An entry is accepted while its first authentication lies within the first interval
    of the policy and, for a value like ``4h/5m``, its last one within the second. The
    last authentication is never older than the first, so an entry unused for longer
    than the shorter of the two intervals can not be accepted any more.

    :param value: the policy value
    :raises TypeError: if a time in the value can not be parsed
    """
    first_offset, last_offset, _max_auths = parse_auth_cache_value(value)
    if last_offset is None:
        return first_offset
    return min(first_offset, last_offset)


def _hash_password(password):
    # The same hash algorithm and parameters the rest of privacyIDEA uses for passwords
    # and PINs, so PI_HASH_ALGO_LIST and PI_HASH_ALGO_PARAMS apply here as well.
    return pass_hash(password)


def add_to_cache(username: str, realm: str, resolver: str, password: str,
                 max_age_seconds: int = None) -> int:
    """
    Remember a successful authentication so the next one within the policy's
    window does not have to reach the user store.

    :param username: login name of the user
    :param realm: realm of the user
    :param resolver: resolver name of the user
    :param password: the password that authenticated
    :param max_age_seconds: how long the entry may be used, from the policy.
        Only Redis can act on it - a database row has no lifetime of its own and
        is removed by the cleanup job instead.
    :return: the id of the database row, or 0 if the entry went to Redis (which
        has no row to identify) or if the password was too long to hash and so
        was not cached at all
    """
    try:
        auth_hash = _hash_password(password)
    except PasswordSizeError:
        # The authentication has already succeeded at this point. A password that the hash
        # algorithm refuses to take simply does not get cached, it does not fail the request.
        log.info(f"Not caching the authentication of {username!s}@{realm!s}: the password is "
                 "longer than the hash algorithm accepts.")
        return 0
    log.debug(f'Adding record to auth cache: ({username!r}, {realm!r}, {resolver!r})')
    if redis_auth_cache.add_to_cache(username, realm, resolver, auth_hash, max_age_seconds):
        return 0
    # Can not store timezone aware timestamps!
    first_auth = utc_now()
    record = AuthCache(username, realm, resolver, auth_hash, first_auth, first_auth)
    r = record.save()
    return r


def update_cache(cache_id: int):
    last_auth = utc_now()
    update_stmt = update(AuthCache).where(AuthCache.id == cache_id).values(
        last_auth=last_auth,
        auth_count=AuthCache.auth_count + 1
    )
    db.session.execute(update_stmt)
    db.session.commit()


def delete_from_cache(username: str, realm: str, resolver: str, password: str,
                      last_valid_cache_time: datetime.datetime = None, max_auths: int = 0):
    """
    Deletes all authcache entries that match the user and either match the password, are expired, or have reached the
    maximum number of allowed authentications.

    :param username:
    :param realm:
    :param resolver:
    :param password:
    :param last_valid_cache_time: Oldest valid time for a cache entry to be still valid. I.e., if the first
    authentication of the entry is before this time point, it is not valid anymore.
    :param max_auths: Maximum number of allowed authentications.
    """
    deleted_in_redis = redis_auth_cache.delete_from_cache(username, realm, resolver, password,
                                                         last_valid_cache_time=last_valid_cache_time,
                                                         max_auths=max_auths)
    if deleted_in_redis is not None:
        return deleted_in_redis

    stmt = select(AuthCache).where(AuthCache.username == username,
                                   AuthCache.realm == realm,
                                   AuthCache.resolver == resolver)
    cached_auths = db.session.scalars(stmt).all()

    r = 0
    for cached_auth in cached_auths:
        delete_entry = False
        # if the password matches or the entry is otherwise invalid, we deleted it.
        try:
            if max_auths > 0 and cached_auth.auth_count >= max_auths:
                delete_entry = True
            elif last_valid_cache_time and cached_auth.first_auth < last_valid_cache_time:
                delete_entry = True
            elif verify_pass_hash(password, cached_auth.authentication):
                delete_entry = True

        except ValueError:
            # The stored value can not be read: either no configured algorithm recognises
            # it, or one does but the value is malformed. passlib raises UnknownHashError
            # for the first and a plain ValueError for the second, and both mean the entry
            # can never verify again. An over-long password does not arrive here, because
            # verify_pass_hash() answers that with False.
            log.debug(f"Unreadable authcache entry for user {username!s}@{realm!s}.")
            delete_entry = True
        if delete_entry:
            r += 1
            db.session.delete(cached_auth)
    db.session.commit()
    return r


def cleanup(minutes: int) -> int:
    """
    Will delete all authcache entries, where last_auth column is older than
    the given minutes.

    :param minutes: Age of the last_authentication in minutes
    :return: Number of deleted cache entries
    """
    cleanuptime = utc_now() - datetime.timedelta(minutes=minutes)
    delete_stmt = delete(AuthCache).where(AuthCache.last_auth < cleanuptime)
    result = db.session.execute(delete_stmt)
    db.session.commit()
    return result.rowcount


def verify_in_cache(username, realm, resolver, password, first_auth=None, last_auth=None,
                    max_auths=0):
    """
    Verify if the given credentials are cached and if the time is correct.

    :param username:
    :param realm:
    :param resolver:
    :param password:
    :param first_auth: The timestamp when the entry was first written to the
        cache. Only find newer entries
    :param last_auth: The timestamp when the entry was last successfully
        verified. Only find newer entries
    :param max_auths: Maximum number of times the authcache entry can be used to skip
        authentication, as defined by ACTION.AUTH_CACHE policy. Will return False if the current number of
        authentications + 1 of the cached authentication exceeds this value.
    :type max_auths: int
    :return:
    """
    cached = redis_auth_cache.verify_in_cache(username, realm, resolver, password,
                                              first_auth=first_auth, last_auth=last_auth,
                                              max_auths=max_auths)
    if cached is not None:
        # Redis holds the cached authentications, so its answer is the whole
        # answer - a miss there is a miss, not a reason to look in the database
        return cached

    result = False

    select_stmt = select(AuthCache).where(AuthCache.username == username, AuthCache.realm == realm,
                                          AuthCache.resolver == resolver)

    if first_auth:
        select_stmt = select_stmt.where(AuthCache.first_auth > first_auth)
    if last_auth:
        select_stmt = select_stmt.where(AuthCache.last_auth > last_auth)

    cached_auths = db.session.scalars(select_stmt).all()

    for cached_auth in cached_auths:
        try:
            result = verify_pass_hash(password, cached_auth.authentication)
        except ValueError:
            # Both an unrecognised and a malformed stored value land here, see
            # delete_from_cache()
            log.debug(f"Unreadable authcache entry for user {username!s}@{realm!s}.")
            result = False

        if result and max_auths > 0:
            # Check if auth_count allows this authentication too
            result = cached_auth.auth_count < max_auths

        if result:
            # Update the last_auth and the auth_count
            update_cache(cached_auth.id)
            break

    if not result:
        # Delete older entries
        delete_from_cache(username, realm, resolver, password, first_auth, max_auths)

    return result
