/**
 * http://www.privacyidea.org
 * (c) cornelius kölbel, cornelius@privacyidea.org
 *
 * 2016-09-01 Cornelius Kölbel, <cornelius.koelbel@netknights.it>
 *
 * This code is free software; you can redistribute it and/or
 * modify it under the terms of the GNU AFFERO GENERAL PUBLIC LICENSE
 * License as published by the Free Software Foundation; either
 * version 3 of the License, or any later version.
 *
 * This code is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU AFFERO GENERAL PUBLIC LICENSE for more details.
 *
 * You should have received a copy of the GNU Affero General Public
 * License along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 */

myApp.factory("ComponentFactory", ["AuthFactory", "$http", "$state",
                                   "$rootScope", "clientUrl", "inform",
                                   function (AuthFactory, $http, $state,
                                             $rootScope, clientUrl, inform) {
        /**
         Each service - just like this service factory - is a singleton.
         */
        return {
            getClientType: function(callback) {
                $http.get(clientUrl + "/", {
                    headers: {'PI-Authorization': AuthFactory.getAuthToken()}
                }).then(function(response) { callback(response.data) },
                    function(error) { AuthFactory.authError(error.data) });
            }
        }
    }]);


// Caches the known clients list. The /client/ endpoint is called at most once
// per page load; consumers (typeaheads on IP-input fields) get a flat array of
// {ip, hostname, apptype, label} entries.
myApp.factory("ClientTypeFactory", ["ComponentFactory",
        function (ComponentFactory) {
    let cached = null;
    let inflight = null;
    const subscribers = [];

    const flatten = function (clientdata) {
        const flat = [];
        const seen = {};
        angular.forEach(clientdata || {}, function (clients, apptype) {
            angular.forEach(clients, function (client) {
                const key = client.ip + "|" + (client.hostname || "") + "|" + apptype;
                if (seen[key]) {
                    return;
                }
                seen[key] = true;
                const parts = [client.ip];
                if (client.hostname) {
                    parts.push("[" + client.hostname + "]");
                }
                parts.push("— " + apptype);
                flat.push({
                    ip: client.ip,
                    hostname: client.hostname,
                    apptype: apptype,
                    label: parts.join(" ")
                });
            });
        });
        return flat;
    };

    return {
        // Lazy-load. callback is invoked with the flat list once available.
        load: function (callback) {
            if (cached) {
                callback(cached);
                return;
            }
            if (callback) {
                subscribers.push(callback);
            }
            if (inflight) {
                return;
            }
            inflight = true;
            ComponentFactory.getClientType(function (data) {
                cached = flatten(data && data.result && data.result.value);
                inflight = false;
                while (subscribers.length) {
                    subscribers.shift()(cached);
                }
            });
        }
    };
}]);


myApp.factory("SubscriptionFactory", ["AuthFactory", "$http", "$state",
                                      "$rootScope", "subscriptionsUrl", "inform",
                                      function (AuthFactory, $http, $state,
                                                $rootScope, subscriptionsUrl,
                                                inform){
    return {
        get: function(callback) {
            $http.get(subscriptionsUrl + "/", {
                headers: {'PI-Authorization': AuthFactory.getAuthToken()}
            }).then(function(response) { callback(response.data) },
                function(error) { AuthFactory.authError(error.data) });
        },
        delete: function(application, callback) {
            $http.delete(subscriptionsUrl + "/" + application, {
                headers: {'PI-Authorization': AuthFactory.getAuthToken()}
            }).then(function(response) { callback(response.data) },
                function(error) { AuthFactory.authError(error.data) });

        },
        getStatus: function(callback, errorCallback) {
            $http.get(subscriptionsUrl + "/status", {
                headers: {'PI-Authorization': AuthFactory.getAuthToken()}
            }).then(function(response) { callback(response.data) },
                function(error) {
                    // Report to the caller first: authError raises on a response without a
                    // JSON body, which would otherwise leave the caller waiting forever.
                    if (errorCallback) { errorCallback(error); }
                    AuthFactory.authError(error.data);
                });
        }
    }
}]);
